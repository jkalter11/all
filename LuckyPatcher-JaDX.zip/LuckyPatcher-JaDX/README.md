# Lucky Patcher by Chelpus [![Github All Releases](https://img.shields.io/github/downloads/AndroidAppz/LuckyPatcher/total.svg?style=flat-square)]() [![Github Releases](https://img.shields.io/github/downloads/AndroidAppz/LuckyPatcher/latest/total.svg?style=flat-square)]()

Lucky Patcher is a great Android tool to remove ads, modify apps permissions, backup and restore apps, bypass premium applications license verification, and more.

To use all features, you need a rooted device.

Note :
Although stable, functioning of Lucky Patcher can't be 100% guaranteed.
So, you are solely responsible for the use of this application and any problems that may occur on your device (rebooting loop, unstable system, etc...).

## Download
[Download Lucky Patcher from the authors website](http://chelpus.defcon5.biz/) | [Download Lucky Patcher directly from Github](https://github.com/AndroidAppz/LuckyPatcher/releases/latest)

## Custom Patches
A list of custom patches can be found [here](https://github.com/AndroidAppz/LuckyPatcherCustomPatches).

## Note
I ([Bluscream](https://github.com/Bluscream)) created this repository to give people insight in the code, provide a safe download mirror in case [chelpus website](https://lucky-patcher.netbew.com/) gets down and to have a cleaner website in general for this awesome project :)

<details><summary>Statistics</summary>

![https://i.imgur.com/X5x2M1u.png](https://i.imgur.com/X5x2M1u.png)
</details>
