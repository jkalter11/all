package org.tukaani.xz.simple;

public interface SimpleFilter {
    int code(byte[] bArr, int i, int i2);
}
