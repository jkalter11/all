package org.tukaani.xz.common;

public class StreamFlags {
    public long backwardSize = -1;
    public int checkType = -1;
}
