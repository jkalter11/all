package kellinwood.security.zipsigner.optional;

public class KeyNameConflictException extends Exception {
}
