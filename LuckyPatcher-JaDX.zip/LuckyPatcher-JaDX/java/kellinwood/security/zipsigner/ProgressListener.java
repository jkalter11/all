package kellinwood.security.zipsigner;

public interface ProgressListener {
    void onProgress(ProgressEvent progressEvent);
}
