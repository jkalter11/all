package kellinwood.logging;

public interface LoggerFactory {
    LoggerInterface getLogger(String str);
}
