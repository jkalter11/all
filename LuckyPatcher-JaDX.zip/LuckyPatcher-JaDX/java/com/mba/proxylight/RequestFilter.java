package com.mba.proxylight;

public interface RequestFilter {
    boolean filter(Request request);
}
