package net.lingala.zip4j.io;

import java.io.IOException;
import java.io.OutputStream;

public abstract class BaseOutputStream extends OutputStream {
    public void write(int b) throws IOException {
    }
}
