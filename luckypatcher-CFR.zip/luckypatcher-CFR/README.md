# LuckyPatcher
Lucky Patcher is a great Android tool to remove ads, modify apps permissions, backup and restore apps, bypass premium applications license verification, and more. 

To use all features, you need a rooted device. 

Note : 
Although stable, functioning of Lucky Patcher can't be 100% guaranteed. 
So, you are solely responsible for the use of this application and any problems that may occur on your device (rebooting loop, unstable system, etc...). 
