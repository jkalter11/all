/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.mba.proxylight;

import com.mba.proxylight.Request;

public interface RequestFilter {
    public boolean filter(Request var1);
}

