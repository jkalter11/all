/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.google.android.finsky.billing.iab.google.util;

public class Base64DecoderException
extends Exception {
    private static final long serialVersionUID = 1;

    public Base64DecoderException() {
    }

    public Base64DecoderException(String string) {
        super(string);
    }
}

