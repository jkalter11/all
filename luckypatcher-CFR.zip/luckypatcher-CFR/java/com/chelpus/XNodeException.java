/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.chelpus;

public class XNodeException
extends Exception {
    private static final long serialVersionUID = 6194649056119743851L;

    public XNodeException() {
    }

    public XNodeException(String string) {
        super(string);
    }
}

