/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.ActionBar
 *  android.app.Activity
 *  android.app.ActivityManager
 *  android.app.ActivityManager$RunningServiceInfo
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Dialog
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.content.ServiceConnection
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.pm.ActivityInfo
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.pm.ResolveInfo
 *  android.content.pm.ServiceInfo
 *  android.content.pm.Signature
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.RemoteException
 *  android.support.v4.app.FragmentActivity
 *  android.text.SpannableString
 *  android.text.style.ForegroundColorSpan
 *  android.text.style.StyleSpan
 *  android.view.KeyEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.View$OnKeyListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.widget.ArrayAdapter
 *  android.widget.Button
 *  android.widget.CompoundButton
 *  android.widget.CompoundButton$OnCheckedChangeListener
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  com.android.vending.billing.InAppBillingService.LOCK.AddFilesItem
 *  com.android.vending.billing.InAppBillingService.LOCK.AlertDlg
 *  com.android.vending.billing.InAppBillingService.LOCK.BindItem
 *  com.android.vending.billing.InAppBillingService.LOCK.CommandItem
 *  com.android.vending.billing.InAppBillingService.LOCK.ITestServiceInterface
 *  com.android.vending.billing.InAppBillingService.LOCK.ITestServiceInterface$Stub
 *  com.android.vending.billing.InAppBillingService.LOCK.Mount
 *  com.android.vending.billing.InAppBillingService.LOCK.PatchesItemAuto
 *  com.android.vending.billing.InAppBillingService.LOCK.StringItem
 *  com.android.vending.billing.InAppBillingService.LOCK.TypesItem
 *  com.android.vending.billing.InAppBillingService.LOCK.dialogs.Progress_Dialog_Loading
 *  com.android.vending.billing.InAppBillingService.LOCK.listAppsFragment
 *  com.android.vending.billing.InAppBillingService.LOCK.patchActivity
 *  java.io.BufferedReader
 *  java.io.ByteArrayOutputStream
 *  java.io.DataInputStream
 *  java.io.DataOutputStream
 *  java.io.EOFException
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileNotFoundException
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.InputStreamReader
 *  java.io.OutputStream
 *  java.io.PrintStream
 *  java.io.RandomAccessFile
 *  java.io.Reader
 *  java.io.StringReader
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Exception
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.InterruptedException
 *  java.lang.NoSuchMethodError
 *  java.lang.NoSuchMethodException
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.Package
 *  java.lang.Process
 *  java.lang.Runnable
 *  java.lang.Runtime
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.math.BigInteger
 *  java.nio.Buffer
 *  java.nio.ByteBuffer
 *  java.nio.MappedByteBuffer
 *  java.nio.channels.FileChannel
 *  java.nio.channels.FileChannel$MapMode
 *  java.security.InvalidKeyException
 *  java.security.KeyFactory
 *  java.security.KeyPair
 *  java.security.KeyPairGenerator
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 *  java.security.PrivateKey
 *  java.security.PublicKey
 *  java.security.Signature
 *  java.security.SignatureException
 *  java.security.spec.InvalidKeySpecException
 *  java.security.spec.KeySpec
 *  java.security.spec.RSAPublicKeySpec
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Random
 *  java.util.Set
 *  java.util.TimerTask
 *  java.util.concurrent.Semaphore
 *  java.util.jar.JarOutputStream
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  java.util.zip.Adler32
 *  java.util.zip.ZipEntry
 *  java.util.zip.ZipInputStream
 *  javax.xml.parsers.DocumentBuilder
 *  javax.xml.parsers.DocumentBuilderFactory
 *  javax.xml.parsers.ParserConfigurationException
 *  org.json.JSONException
 *  org.json.JSONObject
 *  org.w3c.dom.Document
 *  org.w3c.dom.Element
 *  org.w3c.dom.Node
 *  org.w3c.dom.NodeList
 *  org.xml.sax.InputSource
 *  org.xml.sax.SAXException
 */
package com.chelpus;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.Signature;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.support.v4.app.FragmentActivity;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.vending.billing.InAppBillingService.LOCK.AddFilesItem;
import com.android.vending.billing.InAppBillingService.LOCK.AlertDlg;
import com.android.vending.billing.InAppBillingService.LOCK.BindItem;
import com.android.vending.billing.InAppBillingService.LOCK.CommandItem;
import com.android.vending.billing.InAppBillingService.LOCK.ITestServiceInterface;
import com.android.vending.billing.InAppBillingService.LOCK.Mount;
import com.android.vending.billing.InAppBillingService.LOCK.PatchesItemAuto;
import com.android.vending.billing.InAppBillingService.LOCK.StringItem;
import com.android.vending.billing.InAppBillingService.LOCK.TypesItem;
import com.android.vending.billing.InAppBillingService.LOCK.dialogs.Progress_Dialog_Loading;
import com.android.vending.billing.InAppBillingService.LOCK.listAppsFragment;
import com.android.vending.billing.InAppBillingService.LOCK.patchActivity;
import com.google.android.finsky.billing.iab.google.util.Base64;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TimerTask;
import java.util.concurrent.Semaphore;
import java.util.jar.JarOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.Adler32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import kellinwood.zipio.ZioEntry;
import kellinwood.zipio.ZipInput;
import org.json.JSONException;
import org.json.JSONObject;
import org.tukaani.xz.FilterOptions;
import org.tukaani.xz.LZMA2Options;
import org.tukaani.xz.UnsupportedOptionsException;
import org.tukaani.xz.XZInputStream;
import org.tukaani.xz.XZOutputStream;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class Utils {
    static final String AB = "abcdefghijklmnopqrstuvwxyz";
    static final String AB2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final String LIB_ART = "libart.so";
    private static final String LIB_ART_D = "libartd.so";
    private static final String LIB_DALVIK = "libdvm.so";
    public static final String ROOT_NOT_FOUND = "lucky patcher root not found!";
    private static final String SELECT_RUNTIME_PROPERTY = "persist.sys.dalvik.vm.lib";
    protected static final char[] hexArray;
    private static String internalBusybox;
    static ITestServiceInterface mService;
    static ServiceConnection mServiceConn;
    public static String pattern_check;
    static Random rnd;
    float folder_size = 0.0f;

    static {
        pattern_check = "297451286";
        internalBusybox = "";
        hexArray = "0123456789ABCDEF".toCharArray();
        mServiceConn = null;
        mService = null;
        rnd = new Random();
    }

    public Utils(String string) {
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean XZCompress(File file, File file2) throws OutOfMemoryError {
        try {
            int n;
            FileInputStream fileInputStream = new FileInputStream(file);
            XZOutputStream xZOutputStream = new XZOutputStream((OutputStream)new FileOutputStream(file2), new LZMA2Options());
            byte[] arrby = new byte[2048];
            while ((n = fileInputStream.read(arrby)) != -1) {
                xZOutputStream.write(arrby, 0, n);
            }
            xZOutputStream.finish();
        }
        catch (FileNotFoundException var7_6) {
            System.out.println("File not found for xz compress.");
            var7_6.printStackTrace();
            return false;
        }
        if (!file2.exists()) return false;
        return true;
        catch (UnsupportedOptionsException unsupportedOptionsException) {
            System.out.println("Unsupported options for xz compress.");
            unsupportedOptionsException.printStackTrace();
            return false;
        }
        catch (IOException iOException) {
            System.out.println("IO Error for xz compress.");
            iOException.printStackTrace();
            return false;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean XZDecompress(File file, String string) {
        byte[] arrby = new byte[2048];
        String string2 = null;
        File file2 = new File(string);
        if (!file2.exists() || file2.isFile()) {
            if (file2.isFile()) {
                file2.delete();
            }
            file2.mkdirs();
        }
        if (!file2.exists()) {
            System.out.println("not found dir for ectract xz.");
            return false;
        }
        File file3 = string.endsWith("/") ? new File(string + Utils.removeExtension(file.getName())) : new File(string + "/" + Utils.removeExtension(file.getName()));
        try {
            int n;
            string2 = file.getAbsolutePath();
            XZInputStream xZInputStream = new XZInputStream((InputStream)new FileInputStream(file));
            FileOutputStream fileOutputStream = new FileOutputStream(file3);
            while ((n = xZInputStream.read(arrby)) != -1) {
                fileOutputStream.write(arrby, 0, n);
            }
        }
        catch (FileNotFoundException var11_9) {
            System.err.println("XZDec: Cannot open " + string2 + ": " + var11_9.getMessage());
            file3.delete();
            return false;
        }
        catch (EOFException var9_10) {
            System.err.println("XZDec: Unexpected end of input on " + string2);
            file3.delete();
            return false;
        }
        catch (IOException var7_11) {
            System.err.println("XZDec: Error decompressing from " + string2 + ": " + var7_11.getMessage());
            file3.delete();
            return false;
        }
        if (file3.exists()) {
            return true;
        }
        file3.delete();
        return false;
    }

    public static final void activityToFront() {
        Intent intent = new Intent((Context)listAppsFragment.frag.getContext(), listAppsFragment.frag.getActivity().getClass());
        intent.setFlags(131072);
        listAppsFragment.frag.getContext().startActivity(intent);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void addFileToList(File file, ArrayList<File> arrayList) {
        if (arrayList != null && arrayList.size() > 0) {
            boolean bl = false;
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                if (((File)iterator.next()).length() != file.length()) continue;
                bl = true;
            }
            return;
        }
        if (arrayList == null) {
            return;
        }
        arrayList.add((Object)file);
    }

    /*
     * Exception decompiling
     */
    public static void addFilesToZip(String var0_1, String var1, ArrayList<AddFilesItem> var2_2) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl73 : TryStatement: try { 9[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:507)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void afterPatch(String string, String string2, String string3, String string4, String string5) {
        System.out.println("uid:" + string4);
        if (!string.contains((CharSequence)"copyDC") && !string.contains((CharSequence)"deleteDC")) return;
        {
            File file = Utils.getFileDalvikCache(string2);
            if (file != null) {
                file.delete();
                if (!string.contains((CharSequence)"copyDC")) return;
                {
                    Utils.copyFile(new File(string3), file);
                    if (!file.exists() || file.length() != new File(string3).length()) return;
                    {
                        new File(string3).delete();
                        String[] arrstring = new String[]{"chmod", "644", file.getAbsolutePath()};
                        Utils.run_all_no_root(arrstring);
                        String[] arrstring2 = new String[]{"chown", "1000:" + string4, file.getAbsolutePath()};
                        Utils.run_all_no_root(arrstring2);
                        String[] arrstring3 = new String[]{"chown", "1000." + string4, file.getAbsolutePath()};
                        Utils.run_all_no_root(arrstring3);
                        return;
                    }
                }
            } else {
                if (!string.contains((CharSequence)"copyDC")) return;
                {
                    File file2 = Utils.getFileDalvikCacheName(string2);
                    Utils.copyFile(new File(string3), file2);
                    if (!file2.exists() || file2.length() != new File(string3).length()) return;
                    {
                        new File(string3).delete();
                        String[] arrstring = new String[]{"chmod", "644", file2.getAbsolutePath()};
                        Utils.run_all_no_root(arrstring);
                        String[] arrstring4 = new String[]{"chown", "1000:" + string4, file2.getAbsolutePath()};
                        Utils.run_all_no_root(arrstring4);
                        String[] arrstring5 = new String[]{"chown", "1000." + string4, file2.getAbsolutePath()};
                        Utils.run_all_no_root(arrstring5);
                        return;
                    }
                }
            }
        }
    }

    public static String apply_TAGS(String string, String string2) {
        return string.replaceAll("%PACKAGE_NAME%", string2);
    }

    public static String bytesToHex(byte[] arrby) {
        char[] arrc = new char[2 * arrby.length];
        for (int i = 0; i < arrby.length; ++i) {
            int n = 255 & arrby[i];
            arrc[i * 2] = hexArray[n >>> 4];
            arrc[1 + i * 2] = hexArray[n & 15];
        }
        return new String(arrc);
    }

    /*
     * Exception decompiling
     */
    private static final void calcChecksum(File var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 11[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    private static void calcChecksumOdexFly(int n, int n2, File file) {
        FileChannel fileChannel = new RandomAccessFile(file, "rw").getChannel();
        MappedByteBuffer mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_WRITE, 0, (long)((int)fileChannel.size()));
        Adler32 adler32 = new Adler32();
        mappedByteBuffer.position(n + 12);
        while (n2 > 0) {
            adler32.update((int)mappedByteBuffer.get());
            --n2;
        }
        try {
            int n3 = (int)adler32.getValue();
            mappedByteBuffer.position(n + 8);
            mappedByteBuffer.put((byte)n3);
            mappedByteBuffer.force();
            mappedByteBuffer.position(n + 9);
            mappedByteBuffer.put((byte)(n3 >> 8));
            mappedByteBuffer.force();
            mappedByteBuffer.position(n + 10);
            mappedByteBuffer.put((byte)(n3 >> 16));
            mappedByteBuffer.force();
            mappedByteBuffer.position(n + 11);
            mappedByteBuffer.put((byte)(n3 >> 24));
            mappedByteBuffer.force();
            fileChannel.close();
            return;
        }
        catch (FileNotFoundException var4_7) {
            var4_7.printStackTrace();
            return;
        }
        catch (IOException var3_8) {
            var3_8.printStackTrace();
            return;
        }
    }

    /*
     * Exception decompiling
     */
    private static final void calcSignature(File var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 7[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String changeExtension(String string, String string2) {
        String string3 = "";
        if (string == null) {
            return string3;
        }
        String[] arrstring = string.split("\\.");
        int n = 0;
        while (n < arrstring.length) {
            string3 = n < -1 + arrstring.length ? string3 + arrstring[n] + "." : string3 + string2;
            ++n;
        }
        return string3;
    }

    /*
     * Exception decompiling
     */
    public static int changePackageNameIds(String var0_1, String var1, String var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 14[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean checkBind(BindItem bindItem) {
        if (bindItem.TargetDir.trim().startsWith("~chelpus_disabled~")) {
            return false;
        }
        String string = bindItem.SourceDir.trim();
        String string2 = bindItem.TargetDir.trim();
        String string3 = !string.endsWith("/") ? string.trim() + "/" : string;
        String string4 = !string2.endsWith("/") ? string2.trim() + "/" : string2;
        new File(string2).mkdirs();
        new File(string).mkdirs();
        if (!new File(string2).exists()) {
            Utils.verify_and_run("mkdir", "-p '" + string2 + "'");
        }
        if (!new File(string).exists()) {
            Utils.verify_and_run("mkdir", "-p '" + string + "'");
        }
        try {
            new File(string3 + "test.txt").createNewFile();
        }
        catch (IOException var7_5) {
            var7_5.printStackTrace();
        }
        Utils.run_all("echo '' >'" + string3 + "test.txt'");
        if (!Utils.exists(string4 + "test.txt")) {
            new File(string3 + "test.txt").delete();
            if (!Utils.exists(string3 + "test.txt")) return false;
            Utils.run_all("rm '" + string3 + "test.txt'");
            return false;
        }
        new File(string3 + "test.txt").delete();
        if (!Utils.exists(string3 + "test.txt")) return true;
        Utils.run_all("rm '" + string3 + "test.txt'");
        return true;
    }

    public static boolean checkCoreJarPatch11() {
        try {
            java.security.Signature signature = java.security.Signature.getInstance((String)"SHA1withRSA");
            RSAPublicKeySpec rSAPublicKeySpec = new RSAPublicKeySpec(new BigInteger("12345678", 16), new BigInteger("11", 16));
            signature.initVerify(KeyFactory.getInstance((String)"RSA").generatePublic((KeySpec)rSAPublicKeySpec));
            signature.update("367".getBytes());
            boolean bl = signature.verify("123098".getBytes());
            if (!bl) {
                return false;
            }
            return true;
        }
        catch (NoSuchAlgorithmException var3_3) {
            return false;
        }
        catch (InvalidKeyException var2_4) {
            return false;
        }
        catch (SignatureException var1_5) {
            return false;
        }
        catch (InvalidKeySpecException var0_6) {
            var0_6.printStackTrace();
            return false;
        }
    }

    public static boolean checkCoreJarPatch12() {
        try {
            java.security.Signature signature = java.security.Signature.getInstance((String)"SHA1withRSA");
            RSAPublicKeySpec rSAPublicKeySpec = new RSAPublicKeySpec(new BigInteger("12345678", 16), new BigInteger("11", 16));
            signature.initVerify(KeyFactory.getInstance((String)"RSA").generatePublic((KeySpec)rSAPublicKeySpec));
            signature.update("367".getBytes());
            boolean bl = signature.verify("123098".getBytes(), 1, 5);
            if (!bl) {
                return false;
            }
            return true;
        }
        catch (NoSuchAlgorithmException var3_3) {
            return false;
        }
        catch (InvalidKeyException var2_4) {
            return false;
        }
        catch (SignatureException var1_5) {
            return false;
        }
        catch (InvalidKeySpecException var0_6) {
            var0_6.printStackTrace();
            return false;
        }
    }

    public static boolean checkCoreJarPatch20() {
        return MessageDigest.isEqual((byte[])"12".getBytes(), (byte[])"45".getBytes());
    }

    /*
     * Exception decompiling
     */
    public static boolean checkCoreJarPatch30(PackageManager var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredWhile.transformStructuredChildren(StructuredWhile.java:50)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean checkCoreJarPatch40() {
        mServiceConn = new ServiceConnection(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                boolean bl = false;
                Utils.mService = ITestServiceInterface.Stub.asInterface((IBinder)iBinder);
                try {
                    bl = Utils.mService.checkService();
                    System.out.println("TestService:" + bl);
                }
                catch (RemoteException var4_4) {
                    var4_4.printStackTrace();
                }
                System.out.println("TestService:" + bl);
            }

            public void onServiceDisconnected(ComponentName componentName) {
                System.out.println("Licensing service disconnected.");
                Utils.mService = null;
            }
        };
        ITestServiceInterface iTestServiceInterface = mService;
        boolean bl = false;
        if (iTestServiceInterface != null) return bl;
        try {
            boolean bl2;
            Intent intent = new Intent("com.android.vending.billing.InAppBillingService.LOCK.ITestServiceInterface.BIND");
            intent.setPackage("com.android.vending");
            boolean bl3 = listAppsFragment.getPkgMng().queryIntentServices(intent, 0).isEmpty();
            bl = false;
            if (bl3) return bl;
            Iterator iterator = listAppsFragment.getPkgMng().queryIntentServices(intent, 0).iterator();
            do {
                boolean bl4 = iterator.hasNext();
                bl = false;
                if (!bl4) return bl;
                ResolveInfo resolveInfo = (ResolveInfo)iterator.next();
            } while (resolveInfo.serviceInfo.packageName == null || !(bl2 = resolveInfo.serviceInfo.packageName.equals((Object)listAppsFragment.getInstance().getPackageName())));
            return true;
        }
        catch (SecurityException var4_8) {
            var4_8.printStackTrace();
            return false;
        }
        catch (Exception var3_9) {
            var3_9.printStackTrace();
            return false;
        }
    }

    public static boolean checkRoot(Boolean bl, String string) {
        internalBusybox = string;
        new Thread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             * Lifted jumps to return sites
             */
            public void run() {
                try {
                    if (Utils.exists("/system/bin/su")) {
                        if (listAppsFragment.su) {
                            System.out.println("LuckyPatcher: skip root test.");
                            return;
                        }
                        Utils utils = new Utils("");
                        String[] arrstring = new String[]{"stat -c %a /system/bin/su", internalBusybox + " stat -c %a /system/bin/su", "busybox stat -c %a /system/bin/su"};
                        String string = utils.cmdRoot(arrstring);
                        System.out.println("LuckyPatcher (chek root): get permissions " + string + " /system/bin/su");
                        if (!string.contains((CharSequence)"6755") && string.matches("[0-9]")) {
                            System.out.println("LuckyPatcher (chek root): Permissions /system/bin/su not correct.");
                            Utils.remount("/system", "rw");
                            new Utils("").cmdRoot("chmod 06755 /system/bin/su");
                            Utils.remount("/system", "ro");
                            String string2 = new Utils("").cmdRoot("stat -c %a /system/bin/su");
                            System.out.println("LuckyPatcher (chek root): " + string2 + " /system/bin/su");
                            if (!string2.contains((CharSequence)"6755")) return;
                            System.out.println("LuckyPatcher (chek root): permission /system/bin/su set 06755");
                            return;
                        }
                        System.out.println("LuckyPatcher (chek root): Permissions is true.(/system/bin/su)");
                        return;
                    }
                }
                catch (Exception var1_5) {
                    var1_5.printStackTrace();
                    return;
                }
                if (!Utils.exists("/system/xbin/su")) return;
                new Utils("").cmdRoot("chmod 06777 internalBusybox");
                if (listAppsFragment.su) {
                    System.out.println("LuckyPatcher: skip root test.");
                    return;
                }
                Utils utils = new Utils("");
                String[] arrstring = new String[]{"stat -c %a /system/xbin/su", internalBusybox + " stat -c %a /system/xbin/su", "busybox stat -c %a /system/xbin/su"};
                String string = utils.cmdRoot(arrstring);
                System.out.println("LuckyPatcher (chek root): get permissions " + string + " /system/xbin/su");
                if (!string.contains((CharSequence)"6755") && string.matches("[0-9]")) {
                    System.out.println("LuckyPatcher (chek root): Permissions /system/xbin/su not correct.");
                    Utils.remount("/system", "rw");
                    new Utils("").cmdRoot("chmod 06755 /system/xbin/su");
                    Utils.remount("/system", "ro");
                    String string3 = new Utils("").cmdRoot("stat -c %a /system/xbin/su");
                    System.out.println("LuckyPatcher (chek root): " + string3 + " /system/xbin/su");
                    if (!string3.contains((CharSequence)"6755")) return;
                    System.out.println("LuckyPatcher (chek root): permission /system/xbin/su set 06755");
                    return;
                }
                System.out.println("LuckyPatcher (chek root): Permissions is true.(/system/xbin/su)");
            }
        }).run();
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String checkRuntimeFromCache(String string) {
        int n;
        byte[] arrby;
        byte[] arrby2;
        byte[] arrby3;
        if (listAppsFragment.api < 19) return "DALVIK";
        try {
            FileInputStream fileInputStream = new FileInputStream(Utils.getFileDalvikCache(string));
            arrby2 = new byte[7];
            fileInputStream.read(arrby2);
            fileInputStream.close();
            arrby3 = new byte[]{100, 101, 120};
            arrby = new byte[]{100, 101, 121};
            n = 0;
        }
        catch (FileNotFoundException var6_6) {
            var6_6.printStackTrace();
            return "UNKNOWN";
        }
        catch (IOException var5_7) {
            var5_7.printStackTrace();
            return "UNKNOWN";
        }
        catch (Exception var2_8) {
            var2_8.printStackTrace();
            try {
                System.out.println("Althernative runtime check with java.vm.version");
                String string2 = System.getProperty((String)"java.vm.version");
                if (Integer.parseInt((String)("" + string2.charAt(0))) <= 1) return "DALVIK";
                return "ART";
            }
            catch (Exception var3_10) {
                var3_10.printStackTrace();
                if (listAppsFragment.api < 21) return "DALVIK";
                return "ART";
            }
        }
        while (n < 3) {
            if (arrby2[n] != arrby3[n] && arrby2[n] != arrby[n]) {
                System.out.println("The magic value is not the expected value " + new String(arrby2));
                return "ART";
            }
            ++n;
        }
        return "DALVIK";
    }

    public static int chmod(File file, int n) throws Exception {
        Class class_ = Class.forName((String)"android.os.FileUtils");
        Class[] arrclass = new Class[]{String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE};
        Method method = class_.getMethod("setPermissions", arrclass);
        Object[] arrobject = new Object[]{file.getAbsolutePath(), n, -1, -1};
        return (Integer)method.invoke((Object)null, arrobject);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean classes_test(File file) {
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            ZipInputStream zipInputStream = new ZipInputStream((InputStream)fileInputStream);
            ZipEntry zipEntry = zipInputStream.getNextEntry();
            do {
                if (zipEntry == null) {
                    zipInputStream.close();
                    fileInputStream.close();
                    return false;
                }
                if (zipEntry.getName().toLowerCase().equals((Object)"classes.dex")) {
                    zipInputStream.closeEntry();
                    zipInputStream.close();
                    fileInputStream.close();
                    return true;
                }
                zipEntry = zipInputStream.getNextEntry();
            } while (true);
        }
        catch (Exception var3_4) {
            try {
                boolean bl;
                Iterator iterator = ZipInput.read(file.getAbsolutePath()).getEntries().values().iterator();
                do {
                    if (!iterator.hasNext()) return false;
                } while (!(bl = ((ZioEntry)iterator.next()).getName().toLowerCase().equals((Object)"classes.dex")));
                return true;
            }
            catch (IOException var4_7) {
                var4_7.printStackTrace();
                return false;
            }
        }
    }

    /*
     * Exception decompiling
     */
    public static void clear_dalvik_cache() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static /* varargs */ String cmd(String ... arrstring) {
        int n = 0;
        String string = "";
        Process process = null;
        boolean bl = false;
        int n2 = arrstring.length;
        for (int i = 0; i < n2; ++i) {
            if (!arrstring[i].equals((Object)"skipOut")) continue;
            bl = true;
        }
        int n3 = arrstring.length;
        do {
            if (n >= n3) {
                process.destroy();
                return string;
            }
            String string2 = arrstring[n];
            try {
                if (!string2.equals((Object)"skipOut")) {
                    process = Runtime.getRuntime().exec(new String(string2.getBytes(), "ISO-8859-1"));
                    BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(process.getInputStream()));
                    if (!bl) {
                        String string3;
                        while ((string3 = bufferedReader.readLine()) != null) {
                            string = string + string3 + "\n";
                        }
                        process.waitFor();
                    }
                    new Utils("w").waitLP(2000);
                }
            }
            catch (IOException var10_12) {
                var10_12.printStackTrace();
            }
            catch (InterruptedException var9_10) {
                var9_10.printStackTrace();
            }
            ++n;
        } while (true);
    }

    /*
     * Exception decompiling
     */
    public static /* varargs */ String cmdParam(String ... var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 12[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static int convertByteToInt(byte by) {
        return by & 255;
    }

    public static int convertFourBytesToInt(byte by, byte by2, byte by3, byte by4) {
        return by4 << 24 | (by3 & 255) << 16 | (by2 & 255) << 8 | by & 255;
    }

    /*
     * Exception decompiling
     */
    public static void convertStringToArraysPatch(String var0, String var1_4, byte[] var2_5, byte[] var3_2, byte[] var4_3, byte[] var5_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo.transformStructuredChildren(StructuredDo.java:53)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static void convertToPatchItemAuto(ArrayList<PatchesItemAuto> var0, ArrayList<String> var1_4, ArrayList<String> var2_7, ArrayList<Boolean> var3_2, ArrayList<String> var4_3, ArrayList<String> var5_1, ArrayList<Boolean> var6_6, Boolean var7_5) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo.transformStructuredChildren(StructuredDo.java:53)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo.transformStructuredChildren(StructuredDo.java:53)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static int convertTwoBytesToInt(byte by, byte by2) {
        return (by2 & 255) << 8 | by & 255;
    }

    /*
     * Exception decompiling
     */
    public static void copyArchFiles(ZipInputStream var0_1, JarOutputStream var1, ArrayList<AddFilesItem> var2_2) throws IOException {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo.transformStructuredChildren(StructuredDo.java:53)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredDo.transformStructuredChildren(StructuredDo.java:53)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static void copyFile(File var0_1, File var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static boolean copyFile(String var0_1, String var1, boolean var2_3, boolean var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void copyFolder(File file, File file2) throws Exception {
        if (file.isDirectory()) {
            String[] arrstring;
            if (!file2.exists()) {
                file2.mkdir();
                System.out.println("Directory copied from " + (Object)file + "  to " + (Object)file2);
            }
            if ((arrstring = file.list()).length > 0) {
                for (String string : arrstring) {
                    Utils.copyFolder(new File(file, string), new File(file2, string));
                }
            }
        } else {
            Utils.copyFile(file, file2);
        }
    }

    /*
     * Exception decompiling
     */
    public static int create_DC_root(String var0_1, String var1, String var2_3, String var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static int create_ODEX_root(String var0_2, ArrayList<File> var1_1, String var2_4, String var3_3, String var4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [15[CATCHBLOCK], 14[CATCHBLOCK]], but top level block is 21[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static boolean dalvikvm_copyFile(String string, String string2, String string3) {
        File file = new File(string2);
        File file2 = new File(string3);
        if (file.exists()) {
            Utils.remount(string3, "RW");
            String[] arrstring = new String[]{"dd", "if=" + string2, "of=" + string3};
            Utils.cmdParam(arrstring);
            if (!new File(string3).exists() || file.length() != file2.length()) {
                String[] arrstring2 = new String[]{"busybox", "dd", "if=" + string2, "of=" + string3};
                Utils.cmdParam(arrstring2);
            }
            if (!new File(string3).exists() || file.length() != file2.length()) {
                String[] arrstring3 = new String[]{listAppsFragment.toolfilesdir + "/busybox", "dd", "if=" + string2, "of=" + string3};
                Utils.cmdParam(arrstring3);
            }
            if (file.length() != file2.length() && file.length() != 0) {
                file2.delete();
                System.out.println("Length of Files not equals. Destination deleted!");
                return false;
            }
            System.out.println(file2.length());
            System.out.println("File copied!");
            return true;
        }
        System.out.println("Source File not Found!");
        return false;
    }

    /*
     * Exception decompiling
     */
    public static int dexopt(String var0_2, String var1_1, String var2_4, String var3_3, Boolean var4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static void dexoptcopy() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static Bitmap drawableToBitmap(Drawable drawable) {
        int n;
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable)drawable).getBitmap();
        }
        int n2 = drawable.getIntrinsicWidth();
        if (n2 <= 0) {
            n2 = 1;
        }
        if ((n = drawable.getIntrinsicHeight()) <= 0) {
            n = 1;
        }
        Bitmap bitmap = Bitmap.createBitmap((int)n2, (int)n, (Bitmap.Config)Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    public static boolean exists(String string) {
        if (new File(string).exists()) {
            return true;
        }
        if (!listAppsFragment.su) {
            return false;
        }
        if (!listAppsFragment.startUnderRoot.booleanValue()) {
            Utils utils = new Utils("");
            String[] arrstring = new String[]{"ls " + string};
            String string2 = utils.cmdRoot(arrstring);
            System.out.println(string2);
            if (string2.equals((Object)string)) {
                return true;
            }
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public static void exit() {
        if (listAppsFragment.getConfig().getBoolean("OnBootService", false) || listAppsFragment.patchOnBoot || listAppsFragment.desktop_launch || listAppsFragment.appDisabler || listAppsFragment.binderWidget) ** GOTO lbl9
        System.out.println("Enf: " + Utils.getSELinux());
        if (Utils.getSELinux().equals((Object)"enforce")) {
            new Utils("").cmdRoot(new String[]{"setenforce 1"});
        }
lbl6: // 4 sources:
        do {
            System.out.println("LP - exit.");
            System.exit((int)0);
lbl9: // 2 sources:
            return;
            break;
        } while (true);
        catch (Exception var0) {
            ** continue;
        }
    }

    public static void exitFromRootJava() {
        boolean bl = listAppsFragment.startUnderRoot;
        listAppsFragment.startUnderRoot = false;
        if (bl) {
            System.exit((int)0);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void exitRoot() {
        if (!listAppsFragment.startUnderRoot.booleanValue()) {
            System.out.println("LuckyPatcher: exit root.");
            try {
                if (listAppsFragment.suOutputStream != null) {
                    listAppsFragment.suOutputStream.writeBytes("exit\n");
                }
            }
            catch (IOException var2) {
                var2.printStackTrace();
            }
            catch (Exception var0_1) {
                var0_1.printStackTrace();
            }
            try {
                if (listAppsFragment.suProcess != null) {
                    listAppsFragment.suProcess.destroy();
                }
                if (listAppsFragment.suOutputStream != null) {
                    listAppsFragment.suOutputStream.close();
                }
                if (listAppsFragment.suInputStream != null) {
                    listAppsFragment.suInputStream.close();
                }
                if (listAppsFragment.suErrorInputStream != null) {
                    listAppsFragment.suErrorInputStream.close();
                }
            }
            catch (Exception var1_2) {
                var1_2.printStackTrace();
            }
            listAppsFragment.suProcess = null;
            listAppsFragment.suOutputStream = null;
            listAppsFragment.suInputStream = null;
            listAppsFragment.suErrorInputStream = null;
        }
        listAppsFragment.semaphoreRoot.release();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    private static Mount findMountPointRecursive(String string) {
        try {
            ArrayList<Mount> arrayList = Utils.getMounts();
            File file = new File(string);
            if (file == null) return null;
            for (Mount mount : arrayList) {
                if (!mount.getMountPoint().equals((Object)file)) continue;
                return mount;
            }
            ArrayList arrayList2 = new ArrayList();
            for (Mount mount2 : arrayList) {
                if (!string.startsWith(mount2.getMountPoint().getAbsolutePath())) continue;
                arrayList2.add((Object)mount2);
            }
            Mount mount3 = null;
            Iterator iterator = arrayList2.iterator();
            do {
                if (!iterator.hasNext()) {
                    if (mount3 == null) return mount3;
                    System.out.println("recursive mount " + mount3.getMountPoint().getAbsolutePath());
                    return mount3;
                }
                Mount mount4 = (Mount)iterator.next();
                if (mount3 == null) {
                    mount3 = mount4;
                }
                if (mount3.getMountPoint().getAbsolutePath().length() >= mount4.getMountPoint().getAbsolutePath().length()) continue;
                mount3 = mount4;
            } while (true);
        }
        catch (Exception var1_8) {
            var1_8.printStackTrace();
            return null;
        }
    }

    /*
     * Exception decompiling
     */
    public static void fixCRCart(File var0_1, ArrayList<File> var1, String var2_3, String var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 34[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void fixadler(File file) {
        try {
            String[] arrstring = new String[]{"chmod", "777", file.getAbsolutePath()};
            Utils.cmdParam(arrstring);
            Utils.calcSignature(file);
            Utils.calcChecksum(file);
            return;
        }
        catch (Exception var1_2) {
            var1_2.printStackTrace();
            return;
        }
    }

    /*
     * Exception decompiling
     */
    public static void fixadlerOdex(File var0_1, String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [5[TRYBLOCK]], but top level block is 26[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String gen_sha1withrsa(String string) {
        byte[] arrby = new byte[string.length()];
        rnd.nextBytes(arrby);
        return Base64.encode(arrby);
    }

    public static Drawable getApkIcon(String string) {
        PackageManager packageManager = listAppsFragment.getPkgMng();
        PackageInfo packageInfo = packageManager.getPackageArchiveInfo(string, 1);
        if (packageInfo != null) {
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            if (Build.VERSION.SDK_INT >= 8) {
                applicationInfo.sourceDir = string;
                applicationInfo.publicSourceDir = string;
            }
            return applicationInfo.loadIcon(packageManager);
        }
        return null;
    }

    public static ApplicationInfo getApkInfo(String string) {
        PackageInfo packageInfo = listAppsFragment.getPkgMng().getPackageArchiveInfo(string, 1);
        if (packageInfo != null) {
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            if (Build.VERSION.SDK_INT >= 8) {
                applicationInfo.sourceDir = string;
                applicationInfo.publicSourceDir = string;
            }
            return applicationInfo;
        }
        return null;
    }

    public static String getApkLabelName(String string) {
        PackageManager packageManager = listAppsFragment.getPkgMng();
        PackageInfo packageInfo = packageManager.getPackageArchiveInfo(string, 1);
        if (packageInfo != null) {
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            if (Build.VERSION.SDK_INT >= 8) {
                applicationInfo.sourceDir = string;
                applicationInfo.publicSourceDir = string;
            }
            return applicationInfo.loadLabel(packageManager).toString();
        }
        return null;
    }

    public static PackageInfo getApkPackageInfo(String string) {
        PackageInfo packageInfo = listAppsFragment.getPkgMng().getPackageArchiveInfo(string, 1);
        if (packageInfo != null) {
            return packageInfo;
        }
        return null;
    }

    public static void getAssets(String string, String string2) throws IOException {
        int n;
        new File(string2).mkdirs();
        InputStream inputStream = listAppsFragment.getRes().getAssets().open(string);
        FileOutputStream fileOutputStream = new FileOutputStream(string2 + "/" + string);
        byte[] arrby = new byte[8192];
        while ((n = inputStream.read(arrby)) != -1) {
            fileOutputStream.write(arrby, 0, n);
        }
        inputStream.close();
        fileOutputStream.flush();
        fileOutputStream.close();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SpannableString getColoredText(String string, int n, String string2) {
        SpannableString spannableString = new SpannableString((CharSequence)string);
        try {
            boolean bl = string2.toLowerCase().contains((CharSequence)"bold");
            int n2 = 0;
            if (bl) {
                n2 = 1;
            }
            if (string2.toLowerCase().contains((CharSequence)"bold_italic")) {
                n2 = 3;
            }
            if (string2.toLowerCase().contains((CharSequence)"italic")) {
                n2 = 2;
            }
            spannableString.setSpan((Object)new ForegroundColorSpan(n), 0, string.length(), 0);
            spannableString.setSpan((Object)new StyleSpan(n2), 0, string.length(), 0);
            return spannableString;
        }
        catch (Exception var4_6) {
            var4_6.printStackTrace();
            if (string.length() == 0) {
                string = " ";
            }
            return new SpannableString((CharSequence)string);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static SpannableString getColoredText(String string, String string2, String string3) {
        SpannableString spannableString = new SpannableString((CharSequence)string);
        try {
            boolean bl = string3.toLowerCase().contains((CharSequence)"bold");
            int n = 0;
            if (bl) {
                n = 1;
            }
            if (string3.toLowerCase().contains((CharSequence)"bold_italic")) {
                n = 3;
            }
            if (string3.toLowerCase().contains((CharSequence)"italic")) {
                n = 2;
            }
            if (!string2.equals((Object)"")) {
                spannableString.setSpan((Object)new ForegroundColorSpan(Color.parseColor((String)string2)), 0, string.length(), 0);
            }
            spannableString.setSpan((Object)new StyleSpan(n), 0, string.length(), 0);
            return spannableString;
        }
        catch (Exception var4_6) {
            var4_6.printStackTrace();
            if (string.length() == 0) {
                string = " ";
            }
            return new SpannableString((CharSequence)string);
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String getCurrentRuntimeValue() {
        try {
            if (listAppsFragment.runtime.contains((CharSequence)"ART")) {
                return "ART";
            }
            if (!listAppsFragment.runtime.contains((CharSequence)"DALVIK")) return "ART";
            return "Dalvik";
        }
        catch (Exception var0) {
            var0.printStackTrace();
            try {
                Class class_ = Class.forName((String)"android.os.SystemProperties");
                try {
                    Method method = class_.getMethod("get", new Class[]{String.class, String.class});
                    if (method == null) {
                        return "WTF?!";
                    }
                    try {
                        String string = (String)method.invoke((Object)class_, new Object[]{"persist.sys.dalvik.vm.lib", "Dalvik"});
                        System.out.println(string);
                        if ("libdvm.so".equals((Object)string)) {
                            return "Dalvik";
                        }
                        if ("libart.so".equals((Object)string)) {
                            return "ART";
                        }
                        if (!"libartd.so".equals((Object)string)) return string;
                        return "ART debug build";
                    }
                    catch (IllegalAccessException var9_4) {
                        return "IllegalAccessException";
                    }
                    catch (InvocationTargetException var7_5) {
                        return "InvocationTargetException";
                    }
                }
                catch (NoSuchMethodException var5_6) {
                    return "SystemProperties.get(String key, String def) method is not found";
                }
            }
            catch (ClassNotFoundException var3_7) {
                var3_7.printStackTrace();
                return "Dalvik";
            }
            catch (Exception var1_8) {
                var1_8.printStackTrace();
                return "Dalvik";
            }
            catch (IllegalArgumentException illegalArgumentException) {
                return "IllegalArgumentException";
            }
        }
    }

    /*
     * Exception decompiling
     */
    public static ArrayList<File> getCustomPatchesForPkg(String var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl38 : TryStatement: try { 3[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:507)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static File getDirs(File file) {
        String[] arrstring = file.toString().split(File.separator);
        String string = "";
        for (int i = 0; i < arrstring.length; ++i) {
            if (i == -1 + arrstring.length) continue;
            string = string + arrstring[i] + File.separator;
        }
        return new File(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static File getFileDalvikCache(String string) {
        if (listAppsFragment.api >= 23 && !string.startsWith("/system/")) {
            String string2 = "";
            File file = new File(string);
            if (new File("/data/dalvik-cache/arm").exists() && new File("/data/dalvik-cache/arm").isDirectory()) {
                string2 = "/arm";
            }
            if (new File("/data/dalvik-cache/arm64").exists() && new File("/data/dalvik-cache/arm64").isDirectory()) {
                string2 = "/arm64";
            }
            if (new File("/data/dalvik-cache/x86").exists() && new File("/data/dalvik-cache/x86").isDirectory()) {
                string2 = "/x86";
            }
            if (new File("/data/dalvik-cache/x86_64").exists() && new File("/data/dalvik-cache/x86_64").isDirectory()) {
                string2 = "/x86_64";
            }
            String string3 = Utils.changeExtension(file.getName(), "odex");
            if (!string.startsWith("/system")) {
                File file2;
                File file3;
                if (string2.equals((Object)"/arm64") && (file2 = new File((Object)Utils.getDirs(file) + "/oat/arm/" + string3)).exists() && file2.length() != 0) {
                    string2 = "/arm";
                }
                if ((file3 = new File((Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3)).exists()) {
                    return file3;
                }
            }
        }
        String string4 = string.replaceAll("/", "@");
        while (string4.startsWith("@")) {
            string4 = string4.replaceFirst("@", "");
        }
        String string5 = string4 + "@classes.dex";
        String string6 = "";
        if (listAppsFragment.startUnderRoot.booleanValue()) {
            try {
                string6 = new Utils("").findFileContainText(new File("/data/dalvik-cache"), string5);
                if (string6.startsWith("/data/dalvik-cache/arm/") && new File("/data/dalvik-cache/arm64/" + string5).exists()) {
                    String string7;
                    string6 = string7 = "/data/dalvik-cache/arm64/" + string5;
                }
            }
            catch (IOException var5_10) {
                var5_10.printStackTrace();
            }
            catch (Exception var4_11) {
                var4_11.printStackTrace();
            }
            if (string6.equals((Object)"")) return null;
            {
                System.out.println("" + string6);
                if (!new File(string6).exists()) return null;
                return new File(string6);
            }
        }
        if (new File("/data/dalvik-cache/x86/" + string5).exists()) {
            return new File("/data/dalvik-cache/x86/" + string5);
        }
        if (new File("/data/dalvik-cache/x86_64/" + string5).exists()) {
            return new File("/data/dalvik-cache/x86_64/" + string5);
        }
        if (new File("/data/dalvik-cache/arm64/" + string5).exists()) {
            return new File("/data/dalvik-cache/arm64/" + string5);
        }
        if (new File("/data/dalvik-cache/arm/" + string5).exists()) {
            return new File("/data/dalvik-cache/arm/" + string5);
        }
        if (!new File("/data/dalvik-cache/" + string5).exists()) return null;
        return new File("/data/dalvik-cache/" + string5);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static File getFileDalvikCacheName(String string) {
        File file;
        File file2;
        if (new File("/data/art-cache/").exists()) {
            String string2 = string.replaceAll("/", "@");
            while (string2.startsWith("@")) {
                string2 = string2.replaceFirst("@", "");
            }
            String string3 = string2 + ".oat";
            if (new File("/data/art-cache/" + string3).exists()) {
                System.out.println("\nLuckyPatcher: found dalvik-cache! " + "/data/art-cache/" + string3);
                return new File("/data/art-cache/" + string3);
            }
        }
        String[] arrstring = new String[]{"/data/dalvik-cache/", "/data/dalvik-cache/arm64/", "/data/dalvik-cache/arm/", "/data/dalvik-cache/x86/", "/data/dalvik-cache/x86_64/", "/sd-ext/data/dalvik-cache/", "/cache/dalvik-cache/", "/sd-ext/data/cache/dalvik-cache/", "/data/cache/dalvik-cache/"};
        String string4 = string.replaceAll("/", "@");
        while (string4.startsWith("@")) {
            string4 = string4.replaceFirst("@", "");
        }
        String string5 = string4 + "@classes.dex";
        System.out.println("dalvikfile: " + string5);
        File file3 = null;
        for (String string6 : arrstring) {
            if (!new File(string6 + string5).exists()) continue;
            System.out.println("\nLuckyPatcher: found dalvik-cache! " + string6 + string5);
            file3 = new File(string6 + string5);
        }
        if (file3 == null) {
            if (Utils.exists("/data/dalvik-cache/arm") || Utils.exists("/data/dalvik-cache/arm64") || Utils.exists("/data/dalvik-cache/x86") || Utils.exists("/data/dalvik-cache/x86_64")) {
                if (Utils.exists("/data/dalvik-cache/arm")) {
                    file3 = new File("/data/dalvik-cache/arm/" + string5);
                }
                if (Utils.exists("/data/dalvik-cache/arm64")) {
                    file3 = new File("/data/dalvik-cache/arm64/" + string5);
                }
                if (Utils.exists("/data/dalvik-cache/x86")) {
                    file3 = new File("/data/dalvik-cache/x86/" + string5);
                }
                if (Utils.exists("/data/dalvik-cache/x86_64")) {
                    file3 = new File("/data/dalvik-cache/x86_64/" + string5);
                }
            } else {
                file3 = new File("/data/dalvik-cache/" + string5);
            }
        }
        if (listAppsFragment.api < 23) return file3;
        if (string.startsWith("/system/")) return file3;
        String string7 = "";
        File file4 = new File(string);
        if (listAppsFragment.startUnderRoot.booleanValue()) {
            if (new File("/data/dalvik-cache/arm").exists() && new File("/data/dalvik-cache/arm").isDirectory()) {
                string7 = "/arm";
            }
            if (new File("/data/dalvik-cache/arm64").exists() && new File("/data/dalvik-cache/arm64").isDirectory()) {
                string7 = "/arm64";
            }
            if (new File("/data/dalvik-cache/x86").exists() && new File("/data/dalvik-cache/x86").isDirectory()) {
                string7 = "/x86";
            }
            if (new File("/data/dalvik-cache/x86_64").exists() && new File("/data/dalvik-cache/x86_64").isDirectory()) {
                string7 = "/x86_64";
            }
        } else {
            if (Utils.exists("/data/dalvik-cache/arm")) {
                string7 = "/arm";
            }
            if (Utils.exists("/data/dalvik-cache/arm64")) {
                string7 = "/arm64";
            }
            if (Utils.exists("/data/dalvik-cache/x86")) {
                string7 = "/x86";
            }
            if (Utils.exists("/data/dalvik-cache/x86_64")) {
                string7 = "/x86_64";
            }
        }
        String string8 = Utils.changeExtension(file4.getName(), "odex");
        if (string.startsWith("/system")) return file3;
        if (string7.equals((Object)"/arm64") && (file2 = new File((Object)Utils.getDirs(file4) + "/oat/arm/" + string8)).exists() && file2.length() != 0) {
            string7 = "/arm";
        }
        if ((file = new File((Object)Utils.getDirs(file4) + "/oat" + string7 + "/" + string8)).exists()) return file;
        return file3;
    }

    /*
     * Exception decompiling
     */
    public static void getFilesWithPkgName(String var0_1, File var1, ArrayList<File> var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [1[TRYBLOCK]], but top level block is 9[FORLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static boolean getMethodsIds(String var0_1, ArrayList<CommandItem> var1, boolean var2_3, boolean var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static ArrayList<Mount> getMounts() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String getOdexForCreate(String string, String string2) {
        boolean bl;
        if (listAppsFragment.startUnderRoot != null && listAppsFragment.startUnderRoot.booleanValue()) {
            System.out.println("Start under Root");
        } else {
            if (listAppsFragment.startUnderRoot == null) {
                System.out.println("uderRoot not defined");
            }
            if (!listAppsFragment.startUnderRoot.booleanValue()) {
                System.out.println("uderRoot false");
            }
        }
        File file = new File(string);
        String string3 = "";
        if (listAppsFragment.api >= 23) {
            String string4 = Utils.changeExtension(file.getName(), "odex");
            if (listAppsFragment.startUnderRoot.booleanValue()) {
                if (new File("/data/dalvik-cache/arm").exists() && new File("/data/dalvik-cache/arm").isDirectory()) {
                    string3 = "/arm";
                }
                if (new File("/data/dalvik-cache/arm64").exists() && new File("/data/dalvik-cache/arm64").isDirectory()) {
                    string3 = "/arm64";
                }
                if (new File("/data/dalvik-cache/x86").exists() && new File("/data/dalvik-cache/x86").isDirectory()) {
                    string3 = "/x86";
                }
                if (new File("/data/dalvik-cache/x86_64").exists() && new File("/data/dalvik-cache/x86_64").isDirectory()) {
                    string3 = "/x86_64";
                }
                if (!string3.equals((Object)"") && new File("/data/dalvik-cache" + string3).exists() && new File("/data/dalvik-cache" + string3).isDirectory()) {
                    System.out.println(string3 + " to dalvik cache found");
                    System.out.println("check " + (Object)Utils.getDirs(file) + "/oat" + string3);
                    if (!new File((Object)Utils.getDirs(file) + "/oat" + string3).exists() || !new File((Object)Utils.getDirs(file) + "/oat" + string3).isDirectory()) {
                        new File((Object)Utils.getDirs(file) + "/oat" + string3).mkdirs();
                        System.out.println("try make dirs");
                        if (new File((Object)Utils.getDirs(file) + "/oat" + string3).exists()) {
                            System.out.println("dirs created");
                            if (!string2.equals((Object)"0")) {
                                String[] arrstring = new String[]{"chmod", "755", (Object)Utils.getDirs(file) + "/oat"};
                                Utils.run_all_no_root(arrstring);
                                String[] arrstring2 = new String[]{"chown", "1000." + string2, (Object)Utils.getDirs(file) + "/oat"};
                                Utils.run_all_no_root(arrstring2);
                                String[] arrstring3 = new String[]{"chown", "1000:" + string2, (Object)Utils.getDirs(file) + "/oat"};
                                Utils.run_all_no_root(arrstring3);
                                String[] arrstring4 = new String[]{"chmod", "755", (Object)Utils.getDirs(file) + "/oat" + string3};
                                Utils.run_all_no_root(arrstring4);
                                String[] arrstring5 = new String[]{"chown", "1000." + string2, (Object)Utils.getDirs(file) + "/oat" + string3};
                                Utils.run_all_no_root(arrstring5);
                                String[] arrstring6 = new String[]{"chown", "1000:" + string2, (Object)Utils.getDirs(file) + "/oat" + string3};
                                Utils.run_all_no_root(arrstring6);
                            } else {
                                String[] arrstring = new String[]{"chmod", "755", (Object)Utils.getDirs(file) + "/oat"};
                                Utils.run_all_no_root(arrstring);
                                String[] arrstring7 = new String[]{"chown", "0." + string2, (Object)Utils.getDirs(file) + "/oat"};
                                Utils.run_all_no_root(arrstring7);
                                String[] arrstring8 = new String[]{"chown", "0:" + string2, (Object)Utils.getDirs(file) + "/oat"};
                                Utils.run_all_no_root(arrstring8);
                                String[] arrstring9 = new String[]{"chmod", "755", (Object)Utils.getDirs(file) + "/oat" + string3};
                                Utils.run_all_no_root(arrstring9);
                                String[] arrstring10 = new String[]{"chown", "0." + string2, (Object)Utils.getDirs(file) + "/oat" + string3};
                                Utils.run_all_no_root(arrstring10);
                                String[] arrstring11 = new String[]{"chown", "0:" + string2, (Object)Utils.getDirs(file) + "/oat" + string3};
                                Utils.run_all_no_root(arrstring11);
                            }
                        }
                    }
                }
            } else {
                if (Utils.exists("/data/dalvik-cache/arm")) {
                    string3 = "/arm";
                }
                if (Utils.exists("/data/dalvik-cache/arm64")) {
                    string3 = "/arm64";
                }
                if (Utils.exists("/data/dalvik-cache/x86")) {
                    string3 = "/x86";
                }
                if (Utils.exists("/data/dalvik-cache/x86_64")) {
                    string3 = "/x86_64";
                }
                if (!string3.equals((Object)"") && Utils.exists("/data/dalvik-cache" + string3) && !Utils.exists((Object)Utils.getDirs(file) + "/oat" + string3)) {
                    Utils.run_all("mkdir -p '" + (Object)Utils.getDirs(file) + "/oat" + string3 + "'");
                    if (Utils.exists((Object)Utils.getDirs(file) + "/oat" + string3)) {
                        if (!string2.equals((Object)"0")) {
                            Utils.run_all("chmod 755 " + (Object)Utils.getDirs(file) + "/oat");
                            Utils.run_all("chown 1000." + string2 + " " + (Object)Utils.getDirs(file) + "/oat");
                            Utils.run_all("chown 1000:" + string2 + " " + (Object)Utils.getDirs(file) + "/oat");
                            Utils.run_all("chmod 755 " + (Object)Utils.getDirs(file) + "/oat" + string3);
                            Utils.run_all("chown 1000." + string2 + " " + (Object)Utils.getDirs(file) + "/oat" + string3);
                            Utils.run_all("chown 1000:" + string2 + " " + (Object)Utils.getDirs(file) + "/oat" + string3);
                        } else {
                            Utils.run_all("chmod 755 " + (Object)Utils.getDirs(file) + "/oat");
                            Utils.run_all("chown 0." + string2 + " " + (Object)Utils.getDirs(file) + "/oat");
                            Utils.run_all("chown 0:" + string2 + " " + (Object)Utils.getDirs(file) + "/oat");
                            Utils.run_all("chmod 755 " + (Object)Utils.getDirs(file) + "/oat" + string3);
                            Utils.run_all("chown 0." + string2 + " " + (Object)Utils.getDirs(file) + "/oat" + string3);
                            Utils.run_all("chown 0:" + string2 + " " + (Object)Utils.getDirs(file) + "/oat" + string3);
                        }
                    }
                }
            }
            if (!string3.equals((Object)"/arm64")) return (Object)Utils.getDirs(file) + "/oat" + string3 + "/" + string4;
            File file2 = new File((Object)Utils.getDirs(file) + "/oat/arm/" + string4);
            if (!file2.exists()) return (Object)Utils.getDirs(file) + "/oat" + string3 + "/" + string4;
            if (file2.length() == 0) return (Object)Utils.getDirs(file) + "/oat" + string3 + "/" + string4;
            string3 = "/arm";
            return (Object)Utils.getDirs(file) + "/oat" + string3 + "/" + string4;
        }
        if (listAppsFragment.startUnderRoot.booleanValue()) {
            if (new File("/data/dalvik-cache/arm").exists() && new File("/data/dalvik-cache/arm").isDirectory()) {
                string3 = "/arm";
            }
            if (new File("/data/dalvik-cache/arm64").exists() && new File("/data/dalvik-cache/arm64").isDirectory()) {
                string3 = "/arm64";
            }
            if (new File("/data/dalvik-cache/x86").exists() && new File("/data/dalvik-cache/x86").isDirectory()) {
                string3 = "/x86";
            }
            if (new File("/data/dalvik-cache/x86_64").exists() && new File("/data/dalvik-cache/x86_64").isDirectory()) {
                string3 = "/x86_64";
            }
            boolean bl2 = string3.equals((Object)"");
            bl = false;
            if (bl2) return Utils.changeExtension(string, "odex");
            boolean bl3 = new File("/data/dalvik-cache" + string3).exists();
            bl = false;
            if (!bl3) return Utils.changeExtension(string, "odex");
            boolean bl4 = new File("/data/dalvik-cache" + string3).isDirectory();
            bl = false;
            if (!bl4) return Utils.changeExtension(string, "odex");
            System.out.println(string3 + " to dalvik cache found");
            System.out.println("check " + (Object)Utils.getDirs(file) + string3);
            if (new File((Object)Utils.getDirs(file) + string3).exists()) {
                if (new File((Object)Utils.getDirs(file) + string3).isDirectory()) return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
            }
            new File((Object)Utils.getDirs(file) + string3).mkdirs();
            System.out.println("try make dirs");
            if (!new File((Object)Utils.getDirs(file) + string3).exists()) return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
            System.out.println("dirs created");
            if (!string2.equals((Object)"0")) {
                String[] arrstring = new String[]{"chmod", "755", (Object)Utils.getDirs(file) + string3};
                Utils.run_all_no_root(arrstring);
                String[] arrstring12 = new String[]{"chown", "1000." + string2, (Object)Utils.getDirs(file) + string3};
                Utils.run_all_no_root(arrstring12);
                String[] arrstring13 = new String[]{"chown", "1000:" + string2, (Object)Utils.getDirs(file) + string3};
                Utils.run_all_no_root(arrstring13);
                return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
            }
            String[] arrstring = new String[]{"chmod", "755", (Object)Utils.getDirs(file) + string3};
            Utils.run_all_no_root(arrstring);
            String[] arrstring14 = new String[]{"chown", "0." + string2, (Object)Utils.getDirs(file) + string3};
            Utils.run_all_no_root(arrstring14);
            String[] arrstring15 = new String[]{"chown", "0:" + string2, (Object)Utils.getDirs(file) + string3};
            Utils.run_all_no_root(arrstring15);
            return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
        }
        if (Utils.exists("/data/dalvik-cache/arm")) {
            string3 = "/arm";
        }
        if (Utils.exists("/data/dalvik-cache/arm64")) {
            string3 = "/arm64";
        }
        if (Utils.exists("/data/dalvik-cache/x86")) {
            string3 = "/x86";
        }
        if (Utils.exists("/data/dalvik-cache/x86_64")) {
            string3 = "/x86_64";
        }
        boolean bl5 = string3.equals((Object)"");
        bl = false;
        if (bl5) return Utils.changeExtension(string, "odex");
        boolean bl6 = Utils.exists("/data/dalvik-cache" + string3);
        bl = false;
        if (!bl6) return Utils.changeExtension(string, "odex");
        if (Utils.exists((Object)Utils.getDirs(file) + string3)) return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
        Utils.run_all("mkdir -p '" + (Object)Utils.getDirs(file) + string3 + "'");
        if (!Utils.exists((Object)Utils.getDirs(file) + string3)) return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
        if (!string2.equals((Object)"0")) {
            Utils.run_all("chmod 755 " + (Object)Utils.getDirs(file) + string3);
            Utils.run_all("chown 1000." + string2 + " " + (Object)Utils.getDirs(file) + string3);
            Utils.run_all("chown 1000:" + string2 + " " + (Object)Utils.getDirs(file) + string3);
            return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
        }
        Utils.run_all("chmod 755 " + (Object)Utils.getDirs(file) + string3);
        Utils.run_all("chown 0." + string2 + " " + (Object)Utils.getDirs(file) + string3);
        Utils.run_all("chown 0:" + string2 + " " + (Object)Utils.getDirs(file) + string3);
        return (Object)Utils.getDirs(file) + string3 + "/" + Utils.changeExtension(file.getName(), "odex");
    }

    public static String getPermissions(String string) {
        if (!listAppsFragment.startUnderRoot.booleanValue()) {
            String[] arrstring = new String[]{listAppsFragment.toolfilesdir + "/busybox", "stat", "-c", "%a", string};
            String string2 = Utils.cmdParam(arrstring).replaceAll("\n", "").replaceAll("\r", "").trim();
            System.out.println(string2);
            if (!string2.matches("(\\d+)")) {
                System.out.println("try get permission again");
                string2 = Utils.cmdParam("busybox", "stat", "-c", "%a", string).replaceAll("\n", "").replaceAll("\r", "").trim();
            }
            if (!string2.matches("(\\d+)")) {
                return "";
            }
            return string2;
        }
        String[] arrstring = new String[]{listAppsFragment.toolfilesdir + "/busybox", "stat", "-c", "%a", string};
        String string3 = Utils.cmdParam(arrstring).replaceAll("\n", "").replaceAll("\r", "").trim();
        System.out.println("'" + string3 + "'");
        if (!string3.matches("(\\d+)")) {
            System.out.println("try get permission again");
            string3 = Utils.cmdParam("busybox", "stat", "-c", "%a", string).replaceAll("\n", "").replaceAll("\r", "").trim();
        }
        if (!string3.matches("(\\d+)")) {
            return "";
        }
        return string3;
    }

    public static PackageInfo getPkgInfo(String string, int n) {
        try {
            PackageInfo packageInfo = listAppsFragment.getPkgMng().getPackageInfo(string, n);
            return packageInfo;
        }
        catch (PackageManager.NameNotFoundException var3_3) {
            var3_3.printStackTrace();
            return null;
        }
        catch (IllegalArgumentException var2_4) {
            var2_4.printStackTrace();
            return null;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String getPlaceForOdex(String string, boolean bl) {
        boolean bl2;
        File file = new File(string);
        String string2 = "";
        if (listAppsFragment.api >= 23) {
            String string3 = Utils.changeExtension(file.getName(), "odex");
            if (bl) {
                if (new File("/data/dalvik-cache/arm").exists() && new File("/data/dalvik-cache/arm").isDirectory()) {
                    string2 = "/arm";
                }
                if (new File("/data/dalvik-cache/arm64").exists() && new File("/data/dalvik-cache/arm64").isDirectory()) {
                    string2 = "/arm64";
                }
                if (new File("/data/dalvik-cache/x86").exists() && new File("/data/dalvik-cache/x86").isDirectory()) {
                    string2 = "/x86";
                }
                if (new File("/data/dalvik-cache/x86_64").exists() && new File("/data/dalvik-cache/x86_64").isDirectory()) {
                    string2 = "/x86_64";
                }
                if (string2.equals((Object)"")) return (Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3;
                if (!new File("/data/dalvik-cache" + string2).exists()) return (Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3;
                if (!new File("/data/dalvik-cache" + string2).isDirectory()) return (Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3;
                return (Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3;
            }
            if (Utils.exists("/data/dalvik-cache/arm")) {
                string2 = "/arm";
            }
            if (Utils.exists("/data/dalvik-cache/arm64")) {
                string2 = "/arm64";
            }
            if (Utils.exists("/data/dalvik-cache/x86")) {
                string2 = "/x86";
            }
            if (Utils.exists("/data/dalvik-cache/x86_64")) {
                string2 = "/x86_64";
            }
            if (string2.equals((Object)"")) return (Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3;
            if (!Utils.exists("/data/dalvik-cache" + string2)) return (Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3;
            return (Object)Utils.getDirs(file) + "/oat" + string2 + "/" + string3;
        }
        if (bl) {
            if (new File("/data/dalvik-cache/arm").exists() && new File("/data/dalvik-cache/arm").isDirectory()) {
                string2 = "/arm";
            }
            if (new File("/data/dalvik-cache/arm64").exists() && new File("/data/dalvik-cache/arm64").isDirectory()) {
                string2 = "/arm64";
            }
            if (new File("/data/dalvik-cache/x86").exists() && new File("/data/dalvik-cache/x86").isDirectory()) {
                string2 = "/x86";
            }
            if (new File("/data/dalvik-cache/x86_64").exists() && new File("/data/dalvik-cache/x86_64").isDirectory()) {
                string2 = "/x86_64";
            }
            boolean bl3 = string2.equals((Object)"");
            bl2 = false;
            if (bl3) return Utils.changeExtension(string, "odex");
            boolean bl4 = new File("/data/dalvik-cache" + string2).exists();
            bl2 = false;
            if (!bl4) return Utils.changeExtension(string, "odex");
            boolean bl5 = new File("/data/dalvik-cache" + string2).isDirectory();
            bl2 = false;
            if (!bl5) return Utils.changeExtension(string, "odex");
            return (Object)Utils.getDirs(file) + string2 + "/" + Utils.changeExtension(file.getName(), "odex");
        }
        if (Utils.exists("/data/dalvik-cache/arm")) {
            string2 = "/arm";
        }
        if (Utils.exists("/data/dalvik-cache/arm64")) {
            string2 = "/arm64";
        }
        if (Utils.exists("/data/dalvik-cache/x86")) {
            string2 = "/x86";
        }
        if (Utils.exists("/data/dalvik-cache/x86_64")) {
            string2 = "/x86_64";
        }
        boolean bl6 = string2.equals((Object)"");
        bl2 = false;
        if (bl6) return Utils.changeExtension(string, "odex");
        boolean bl7 = Utils.exists("/data/dalvik-cache" + string2);
        bl2 = false;
        if (!bl7) return Utils.changeExtension(string, "odex");
        return (Object)Utils.getDirs(file) + string2 + "/" + Utils.changeExtension(file.getName(), "odex");
    }

    public static long getRandom(long l, long l2) {
        long l3;
        long l4;
        Random random = new Random();
        while ((l3 = random.nextLong() << 1 >>> 1) - (l4 = l3 % (1 + (l2 - l))) + (l2 - l) < 0) {
        }
        return l4 + l;
    }

    public static String getRandomStringLowerCase(int n) {
        StringBuilder stringBuilder = new StringBuilder(n);
        for (int i = 0; i < n; ++i) {
            stringBuilder.append("abcdefghijklmnopqrstuvwxyz".charAt(rnd.nextInt("abcdefghijklmnopqrstuvwxyz".length())));
        }
        return stringBuilder.toString();
    }

    public static String getRandomStringUpperLowerCase(int n) {
        StringBuilder stringBuilder = new StringBuilder(n);
        for (int i = 0; i < n; ++i) {
            stringBuilder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".charAt(rnd.nextInt("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".length())));
        }
        return stringBuilder.toString();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static long getRawLength(int n) {
        try {
            InputStream inputStream = listAppsFragment.getRes().openRawResource(n);
            long l = 0;
            byte[] arrby = new byte[8192];
            do {
                int n2;
                if ((n2 = inputStream.read(arrby)) == -1) {
                    System.out.println("LuckyPatcher (RAW): length = " + l);
                    return l;
                }
                l += (long)n2;
            } while (true);
        }
        catch (IOException var1_5) {
            return 0;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean getRawToFile(int n, File file) {
        if (file.exists()) {
            file.delete();
        } else {
            Utils.getDirs(file).mkdirs();
        }
        System.out.println("try get file from raw");
        try {
            byte[] arrby = new byte[8192];
            InputStream inputStream = listAppsFragment.getRes().openRawResource(n);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            int n2 = inputStream.read(arrby);
            while (n2 > 0) {
                int n3;
                fileOutputStream.write(arrby, 0, n2);
                n2 = n3 = inputStream.read(arrby);
            }
            fileOutputStream.flush();
            fileOutputStream.close();
            inputStream.close();
            System.out.println("get file from raw");
            return true;
        }
        catch (IOException var3_7) {
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String getRawToString(int n) {
        String string = "";
        try {
            byte[] arrby = new byte[2048];
            InputStream inputStream = listAppsFragment.getRes().openRawResource(n);
            int n2 = 0;
            do {
                if (n2 == -1) {
                    inputStream.close();
                    return string;
                }
                n2 = inputStream.read(arrby);
                string = string + new String(arrby, "UTF-8");
            } while (true);
        }
        catch (IOException var2_5) {
            return "";
        }
    }

    /*
     * Exception decompiling
     */
    public static void getRoot() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static boolean getRootUid() {
        try {
            boolean bl = System.getProperty((String)"user.name").contains((CharSequence)"root");
            boolean bl2 = false;
            if (bl) {
                bl2 = true;
            }
            return bl2;
        }
        catch (Exception var0_2) {
            var0_2.printStackTrace();
            return false;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String getSELinux() {
        new File("/data/lp");
        var1 = new File("/data/lp/lp_utils");
        if (!var1.exists()) {
            System.out.println("Lucky Patcher not found utils.");
            return "";
        }
        var3_1 = Utils.read_from_file(var1).split("%chelpus%");
        if (var3_1 == null) return "";
        if (var3_1.length <= 0) return "";
        var4_2 = 0;
        ** while (var4_2 < var3_1.length)
lbl-1000: // 1 sources:
        {
            switch (var4_2) {
                case 3: {
                    try {
                        return var3_1[var4_2];
                    }
                    catch (Exception var2_4) {
                        var2_4.printStackTrace();
                        return "";
                    }
                }
            }
            ++var4_2;
            continue;
        }
lbl21: // 1 sources:
        return "";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static void getSignatureKeys() {
        try {
            if (!new File(listAppsFragment.toolfilesdir + "/" + "zipalign").exists() || new File(listAppsFragment.toolfilesdir + "/" + "zipalign").length() != Utils.getRawLength(2131099666)) {
                Utils.getRawToFile(2131099666, new File(listAppsFragment.toolfilesdir + "/zipalign"));
                Utils.chmod(new File((Object)listAppsFragment.getInstance().getFilesDir() + "/" + "zipalign"), 777);
                Utils.run_all("chmod 777 " + (Object)listAppsFragment.getInstance().getFilesDir() + "/" + "zipalign");
            } else {
                Utils.chmod(new File(listAppsFragment.toolfilesdir + "/" + "zipalign"), 777);
                Utils.run_all("chmod 777 " + listAppsFragment.toolfilesdir + "/" + "zipalign");
            }
            Utils.getAssets("testkey.pk8", listAppsFragment.basepath + "/Modified/Keys");
            Utils.getAssets("testkey.sbt", listAppsFragment.basepath + "/Modified/Keys");
            Utils.getAssets("testkey.x509.pem", listAppsFragment.basepath + "/Modified/Keys");
            return;
        }
        catch (Exception var0) {
            var0.printStackTrace();
            return;
        }
    }

    public static String getSimulink(String string) {
        if (listAppsFragment.startUnderRoot.booleanValue()) {
            String string2 = Utils.cmdParam("ls", "-l", string);
            Matcher matcher = Pattern.compile((String)"^.*?\\-\\>\\s+(.*)$").matcher((CharSequence)string2);
            if (matcher.find()) {
                String string3 = matcher.group(1);
                System.out.println("Symlink found: " + string3);
                return string3;
            }
            String[] arrstring = new String[]{listAppsFragment.toolfilesdir + "/busybox", "ls", "-l", string};
            String string4 = Utils.cmdParam(arrstring);
            System.out.println(string4);
            Matcher matcher2 = Pattern.compile((String)"^.*?\\-\\>\\s+(.*)$").matcher((CharSequence)string4);
            if (matcher2.find()) {
                String string5 = matcher2.group(1);
                System.out.println("Symlink found: " + string5);
                return string5;
            }
            System.out.println("No symlink found!");
            return "";
        }
        Utils utils = new Utils("");
        String[] arrstring = new String[]{"ls -l " + string};
        String string6 = utils.cmdRoot(arrstring);
        Matcher matcher = Pattern.compile((String)"^.*?\\-\\>\\s+(.*)$").matcher((CharSequence)string6);
        if (matcher.find()) {
            String string7 = matcher.group(1);
            System.out.println("Symlink found: " + string7);
            return string7;
        }
        Utils utils2 = new Utils("");
        String[] arrstring2 = new String[]{listAppsFragment.toolfilesdir + "/busybox ls -l " + string};
        String string8 = utils2.cmdRoot(arrstring2);
        Matcher matcher3 = Pattern.compile((String)"^.*?\\-\\>\\s+(.*)$").matcher((CharSequence)string8);
        if (matcher3.find()) {
            String string9 = matcher3.group(1);
            System.out.println("Symlink found: " + string9);
            return string9;
        }
        System.out.println("No symlink found!");
        return "";
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public static ArrayList<File> getStoragesReadable() {
        var0 = new ArrayList();
        var0.clear();
        ** for (var3_4 : System.getenv().entrySet())
lbl-1000: // 1 sources:
        {
            try {
                if (!((String)var3_4.getKey()).toString().toLowerCase().contains((CharSequence)"storage") || ((String)var3_4.getKey()).toString().toLowerCase().equals((Object)"android_storage") || !(var5_3 = new File(((String)var3_4.getValue()).toString())).exists() || !var5_3.canRead()) continue;
                var0.add((Object)var5_3);
                continue;
            }
            catch (Exception var4_2) {
                try {
                    var4_2.printStackTrace();
                    continue;
                }
                catch (Exception var1_5) {
                    var1_5.printStackTrace();
                    break;
                }
            }
        }
lbl16: // 2 sources:
        return var0;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive exception aggregation
     */
    public static ArrayList<File> getStoragesWriteable() {
        var0 = new ArrayList();
        var0.clear();
        ** for (var3_4 : System.getenv().entrySet())
lbl-1000: // 1 sources:
        {
            try {
                if (!((String)var3_4.getKey()).toString().toLowerCase().contains((CharSequence)"storage") || ((String)var3_4.getKey()).toString().toLowerCase().equals((Object)"android_storage") || !(var5_3 = new File(((String)var3_4.getValue()).toString())).exists() || !var5_3.canWrite()) continue;
                var0.add((Object)var5_3);
                continue;
            }
            catch (Exception var4_2) {
                try {
                    var4_2.printStackTrace();
                    continue;
                }
                catch (Exception var1_5) {
                    var1_5.printStackTrace();
                    break;
                }
            }
        }
lbl16: // 2 sources:
        return var0;
    }

    /*
     * Exception decompiling
     */
    public static ArrayList<StringItem> getStringIds(String var0_1, ArrayList<String> var1, boolean var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 9[TRYBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String getText(int n) {
        if (listAppsFragment.resources == null) {
            listAppsFragment.resources = listAppsFragment.getRes();
        }
        return listAppsFragment.resources.getString(n);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean getTypesIds(String string, ArrayList<TypesItem> arrayList, boolean bl) {
        System.out.println("scan: " + string);
        Utils.run_all_no_root("chmod", "777", string);
        new ArrayList();
        boolean bl2 = false;
        if (bl) return bl2;
        bl2 = false;
        if (string == null) return bl2;
        boolean bl3 = new File(string).exists();
        bl2 = false;
        if (!bl3) return bl2;
        long l = new File(string).length();
        long l2 = l LCMP 0;
        bl2 = false;
        if (l2 == false) return bl2;
        boolean bl4 = new File(string).exists();
        bl2 = false;
        if (!bl4) return bl2;
        try {
            FileChannel fileChannel = new RandomAccessFile(string, "r").getChannel();
            MappedByteBuffer mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, (long)((int)fileChannel.size()));
            mappedByteBuffer.position(64);
            int n = Utils.convertFourBytesToInt(mappedByteBuffer.get(), mappedByteBuffer.get(), mappedByteBuffer.get(), mappedByteBuffer.get());
            int n2 = Utils.convertFourBytesToInt(mappedByteBuffer.get(), mappedByteBuffer.get(), mappedByteBuffer.get(), mappedByteBuffer.get());
            System.out.println("LuckyPatcher offset_to_data=" + Integer.toHexString((int)n2));
            mappedByteBuffer.position(n2);
            int n3 = 0;
            block9 : for (int i = 0; i < n; ++n3, ++i) {
                byte[] arrby = new byte[]{mappedByteBuffer.get(), mappedByteBuffer.get(), mappedByteBuffer.get(), mappedByteBuffer.get()};
                Iterator iterator = arrayList.iterator();
                do {
                    boolean bl5 = iterator.hasNext();
                    bl2 = false;
                    if (!bl5) continue block9;
                    TypesItem typesItem = (TypesItem)iterator.next();
                    if (arrby[0] != typesItem.Type[0] || arrby[1] != typesItem.Type[1] || arrby[2] != typesItem.Type[2]) continue;
                    byte by = arrby[3];
                    byte by2 = typesItem.Type[3];
                    bl2 = false;
                    if (by != by2) continue;
                    typesItem.id_type[0] = (byte)n3;
                    typesItem.id_type[1] = (byte)(n3 >> 8);
                    typesItem.found_id_type = true;
                } while (true);
            }
            Iterator iterator = arrayList.iterator();
            do {
                if (!iterator.hasNext()) {
                    fileChannel.close();
                    return bl2;
                }
                if (!((TypesItem)iterator.next()).found_id_type) continue;
                bl2 = true;
            } while (true);
        }
        catch (Exception var12_20) {
            try {
                var12_20.printStackTrace();
                return bl2;
            }
            catch (Exception var10_22) {
                try {
                    var10_22.printStackTrace();
                    return bl2;
                }
                catch (Exception var5_23) {
                    System.out.println((Object)var5_23);
                    return bl2;
                }
            }
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static String getXmlAttribute(String string, String string2, String string3) {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        try {
            NodeList nodeList = documentBuilderFactory.newDocumentBuilder().parse(new InputSource((Reader)new StringReader(string))).getElementsByTagName(string2);
            if (nodeList.getLength() >= 0) return "";
            return ((Element)nodeList.item(0)).getAttribute(string3);
        }
        catch (ParserConfigurationException var6_6) {
            var6_6.printStackTrace();
        }
        return "";
        catch (SAXException sAXException) {
            sAXException.printStackTrace();
            return "";
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
            return "";
        }
    }

    public static long getfirstInstallTime(String string, boolean bl) {
        if (listAppsFragment.api > 8 && !bl) {
            try {
                long l = listAppsFragment.getPkgMng().getPackageInfo((String)string, (int)0).lastUpdateTime;
                return l;
            }
            catch (PackageManager.NameNotFoundException var5_3) {
                var5_3.printStackTrace();
                return 0;
            }
        }
        try {
            long l = new File(listAppsFragment.getPkgMng().getPackageInfo((String)string, (int)0).applicationInfo.sourceDir).lastModified();
            return l;
        }
        catch (PackageManager.NameNotFoundException var2_5) {
            var2_5.printStackTrace();
            return 0;
        }
    }

    public static boolean hasXposed() {
        if (System.getenv((String)"CLASSPATH") != null && System.getenv((String)"CLASSPATH").contains((CharSequence)"Xposed")) {
            return true;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean initXposedParam() {
        if (new File("/data/lp/xposed").exists()) ** GOTO lbl52
        if (!new File("/data/lp").exists()) {
            if (listAppsFragment.startUnderRoot.booleanValue()) {
                new File("/data/lp").mkdirs();
                try {
                    new File("/data/lp").setWritable(true, false);
                    new File("/data/lp").setReadable(true, false);
                }
                catch (NoSuchMethodError var43_2) {
                    var43_2.printStackTrace();
                }
                Utils.run_all_no_root(new String[]{"chmod", "777", "/data/lp"});
            } else {
                Utils.run_all("mkdir /data/lp");
                try {
                    new File("/data/lp").setWritable(true, false);
                    new File("/data/lp").setReadable(true, false);
                }
                catch (NoSuchMethodError var39_3) {
                    var39_3.printStackTrace();
                }
                Utils.run_all("chmod 777 /data/lp");
            }
        }
        var23 = new JSONObject();
        try {
            var23.put("patch1", true);
            var23.put("patch2", true);
            var23.put("patch3", true);
            var23.put("patch4", false);
            var23.put("hide", false);
            var23.put("module_on", true);
        }
        catch (JSONException var24_4) {
            var24_4.printStackTrace();
            return false;
        }
        if (listAppsFragment.startUnderRoot.booleanValue()) {
            Utils.save_text_to_file(new File("/data/lp/xposed"), var23.toString());
            new File("/data/lp/xposed").setWritable(true, false);
            new File("/data/lp/xposed").setReadable(true, false);
        }
        ** GOTO lbl43
        catch (NoSuchMethodError var36_5) {
            var36_5.printStackTrace();
        }
        Utils.run_all_no_root(new String[]{"chmod", "777", "/data/lp/xposed"});
        ** GOTO lbl68
lbl43: // 1 sources:
        Utils.save_text_to_file(new File("/data/lp/xposed"), var23.toString());
        try {
            new File("/data/lp/xposed").setWritable(true, false);
            new File("/data/lp/xposed").setReadable(true, false);
        }
        catch (NoSuchMethodError var32_6) {
            var32_6.printStackTrace();
        }
        Utils.run_all("chmod 777 /data/lp/xposed");
        ** GOTO lbl68
lbl52: // 1 sources:
        if (listAppsFragment.startUnderRoot.booleanValue()) {
            try {
                new File("/data/lp/xposed").setWritable(true, false);
                new File("/data/lp/xposed").setReadable(true, false);
            }
            catch (NoSuchMethodError var20_7) {
                var20_7.printStackTrace();
            }
            Utils.run_all_no_root(new String[]{"chmod", "777", "/data/lp/xposed"});
        } else {
            try {
                new File("/data/lp/xposed").setWritable(true, false);
                new File("/data/lp/xposed").setReadable(true, false);
            }
            catch (NoSuchMethodError var0_8) {
                var0_8.printStackTrace();
            }
            Utils.run_all("chmod 777 /data/lp/xposed");
        }
lbl68: // 4 sources:
        try {
            new JSONObject(Utils.read_from_file(new File("/data/lp/xposed")));
        }
        catch (JSONException var17_9) {
            if (listAppsFragment.startUnderRoot.booleanValue()) {
                Utils.run_all_no_root(new String[]{"chmod", "777", "/data/lp/xposed"});
            }
            Utils.run_all("chmod 777 /data/lp/xposed");
        }
        try {
            var2_1 = new JSONObject(Utils.read_from_file(new File("/data/lp/xposed")));
            ** GOTO lbl98
        }
        catch (JSONException var5_10) {
            var5_10.printStackTrace();
            var6_11 = new JSONObject();
            var6_11.put("patch1", true);
            var6_11.put("patch2", true);
            var6_11.put("patch3", true);
            var6_11.put("patch4", false);
            var6_11.put("hide", false);
            var6_11.put("module_on", true);
            if (listAppsFragment.startUnderRoot.booleanValue()) {
                Utils.save_text_to_file(new File("/data/lp/xposed"), var6_11.toString());
                Utils.run_all_no_root(new String[]{"chmod", "777", "/data/lp/xposed"});
            } else {
                Utils.save_text_to_file(new File("/data/lp/xposed"), var6_11.toString());
                Utils.run_all("chmod 777 /data/lp/xposed");
            }
            var2_1 = new JSONObject(Utils.read_from_file(new File("/data/lp/xposed")));
lbl98: // 3 sources:
            var2_1.getBoolean("module_on");
            return true;
        }
        catch (JSONException var3_14) {
            var3_14.printStackTrace();
            return false;
        }
        {
            catch (JSONException var7_12) {
                var7_12.printStackTrace();
                return false;
            }
            catch (JSONException var15_13) {
                var15_13.printStackTrace();
                return false;
            }
        }
    }

    public static final boolean isAds(String string) {
        if (string.contains((CharSequence)".ads.") || string.contains((CharSequence)"adwhirl") || string.contains((CharSequence)"amobee") || string.contains((CharSequence)"burstly") || string.contains((CharSequence)"com.adknowledge.") || string.contains((CharSequence)"cauly.android.ad.") || string.contains((CharSequence)".greystripe.") || string.contains((CharSequence)"inmobi.") || string.contains((CharSequence)"inneractive.api.ads.") || string.contains((CharSequence)".jumptap.adtag.") || string.contains((CharSequence)".mdotm.android.ads.") || string.contains((CharSequence)"medialets.advertising.") || string.contains((CharSequence)".millennialmedia.android.") || string.contains((CharSequence)".mobclix.android.sdk.") || string.contains((CharSequence)".mobfox.sdk.") || string.contains((CharSequence)".adserver.adview.") || string.contains((CharSequence)".mopub.mobileads.") || string.contains((CharSequence)"com.oneriot.") || string.contains((CharSequence)".papaya.offer.") || string.contains((CharSequence)"pontiflex.mobile.webview.sdk.activities") || string.contains((CharSequence)".qwapi.adclient.android.view.") || string.contains((CharSequence)".smaato.SOMA.") || string.contains((CharSequence)".vdopia.client.android.") || string.contains((CharSequence)".zestadz.android.") || string.contains((CharSequence)"com.appenda.") || string.contains((CharSequence)"com.airpush.android.") || string.contains((CharSequence)"com.Leadbolt.") || string.contains((CharSequence)"com.moolah.") || string.contains((CharSequence)"com.tapit.adview.notif.") || string.contains((CharSequence)"com.urbanairship.push.") || string.contains((CharSequence)"com.xtify.android.sdk.") || string.contains((CharSequence)"MediaPlayerWrapper") || string.contains((CharSequence)".vungle.") || string.contains((CharSequence)".tapjoy.") || string.contains((CharSequence)".nbpcorp.") || string.contains((CharSequence)"com.appenda.") || string.contains((CharSequence)".plus1.sdk.") || string.contains((CharSequence)".adsdk.") || string.contains((CharSequence)".mdotm.") || string.contains((CharSequence)"AdView") || string.contains((CharSequence)"mad.ad.")) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean isBootOatCache() {
        if (new File("/data/dalvik-cache/arm/system@framework@boot.oat").exists() || new File("/data/dalvik-cache/arm64/system@framework@boot.oat").exists() || new File("/data/dalvik-cache/x86/system@framework@boot.oat").exists() || new File("/data/dalvik-cache/x86_64/system@framework@boot.oat").exists() || new File("/data/dalvik-cache/oat/arm/system@framework@boot.oat").exists() || new File("/data/dalvik-cache/oat/arm64/system@framework@boot.oat").exists() || new File("/data/dalvik-cache/oat/x86/system@framework@boot.oat").exists() || new File("/data/dalvik-cache/oat/x86_64/system@framework@boot.oat").exists()) {
            return true;
        }
        return false;
    }

    /*
     * Exception decompiling
     */
    public static boolean isCustomPatchesForPkg(String var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl34 : TryStatement: try { 3[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:507)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean isELFfiles(File file) {
        try {
            FileChannel fileChannel = new RandomAccessFile(file, "r").getChannel();
            MappedByteBuffer mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, 0, (long)((int)fileChannel.size()));
            mappedByteBuffer.position(0);
            if (mappedByteBuffer.get() == 127 && mappedByteBuffer.get() == 69 && mappedByteBuffer.get() == 76 && mappedByteBuffer.get() == 70) {
                fileChannel.close();
                System.out.println("Check file: is ELF.");
                return true;
            }
            fileChannel.close();
        }
        catch (FileNotFoundException var2_3) {
            var2_3.printStackTrace();
        }
        catch (IOException var1_4) {
            var1_4.printStackTrace();
        }
        System.out.println("Check file: is not ELF.");
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean isInstalledOnSdCard(String string) {
        if (listAppsFragment.api > 7) {
            int n;
            PackageManager packageManager = listAppsFragment.getPkgMng();
            try {
                n = packageManager.getPackageInfo((String)string, (int)0).applicationInfo.flags;
            }
            catch (PackageManager.NameNotFoundException var5_3) {
                // empty catch block
            }
            if ((n & 262144) != 262144) return false;
            return true;
        }
        try {
            String string2 = listAppsFragment.getPkgMng().getPackageInfo((String)string, (int)0).applicationInfo.sourceDir;
            if (string2.startsWith("/data/")) {
                return false;
            }
            if (string2.contains((CharSequence)"/mnt/")) return true;
            boolean bl = string2.contains((CharSequence)"/sdcard/");
            if (bl) return true;
            return false;
        }
        catch (Throwable var1_6) {
            return false;
        }
    }

    public static boolean isMarketIntent(String string) {
        if (string.toLowerCase().equals((Object)"com.android.vending.billing.inappbillingservice.bind") || string.toLowerCase().equals((Object)"ir.cafebazaar.pardakht.inappbillingservice.bind") || string.toLowerCase().equals((Object)"com.nokia.payment.iapenabler.inappbillingservice.bind") || string.toLowerCase().equals((Object)"net.jhoobin.jhub.inappbillingservice.bind") || string.toLowerCase().equals((Object)"net.jhoobin.jhub.billing.iinappbillingservice") || string.toLowerCase().equals((Object)listAppsFragment.class.getPackage().getName().toLowerCase())) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean isModified(String string, Context context) {
        Object object = null;
        try {
            object = listAppsFragment.getPkgMng().getPackageInfo((String)string, (int)64).signatures[0].toByteArray();
            boolean bl = listAppsFragment.getConfig().getBoolean(string, false);
            if (bl) {
                return true;
            }
        }
        catch (PackageManager.NameNotFoundException var3_4) {
            var3_4.printStackTrace();
        }
        if (Base64.encode((byte[])object).replaceAll("\n", "").equals((Object)"MIIEqDCCA5CgAwIBAgIJAJNurL4H8gHfMA0GCSqGSIb3DQEBBQUAMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTAeFw0wODAyMjkwMTMzNDZaFw0zNTA3MTcwMTMzNDZaMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBANaTGQTexgskse3HYuDZ2CU+Ps1s6x3i/waMqOi8qM1r03hupwqnbOYOuw+ZNVn/2T53qUPn6D1LZLjk/qLT5lbx4meoG7+yMLV4wgRDvkxyGLhG9SEVhvA4oU6Jwr44f46+z4/Kw9oe4zDJ6pPQp8PcSvNQIg1QCAcy4ICXF+5qBTNZ5qaU7Cyz8oSgpGbIepTYOzEJOmc3Li9kEsBubULxWBjf/gOBzAzURNps3cO4JFgZSAGzJWQTT7/emMkod0jb9WdqVA2BVMi7yge54kdVMxHEa5r3b97szI5p58ii0I54JiCUP5lyfTwE/nKZHZnfm644oLIXf6MdW2r+6R8CAQOjgfwwgfkwHQYDVR0OBBYEFEhZAFY9JyxGrhGGBaR0GawJyowRMIHJBgNVHSMEgcEwgb6AFEhZAFY9JyxGrhGGBaR0GawJyowRoYGapIGXMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbYIJAJNurL4H8gHfMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADggEBAHqvlozrUMRBBVEY0NqrrwFbinZaJ6cVosK0TyIUFf/azgMJWr+kLfcHCHJsIGnlw27drgQAvilFLAhLwn62oX6snb4YLCBOsVMR9FXYJLZW2+TcIkCRLXWG/oiVHQGo/rWuWkJgU134NDEFJCJGjDbiLCpe+ZTWHdcwauTJ9pUbo8EvHRkU3cYfGmLaLfgn9gP+pWA7LFQNvXwBnDa6sppCccEX31I828XzgXpJ4O+mDL1/dBd+ek8ZPUP0IgdyZm5MTYPhvVqGCHzzTy3sIeJFymwrsBbmg2OAUNLEMO6nwmocSdN2ClirfxqCzJOLSDE4QyS9BAH6EhY6UFcOaE0=")) return true;
        return false;
    }

    public static final boolean isNetworkAvailable() {
        NetworkInfo networkInfo = ((ConnectivityManager)listAppsFragment.getInstance().getSystemService("connectivity")).getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean isOdex(String string) {
        try {
            File file = new File(string);
            String string2 = Utils.changeExtension(file.getName(), "odex");
            if (listAppsFragment.api < 23) {
                if (new File(Utils.changeExtension(string, "odex")).exists()) return true;
                if (new File((Object)Utils.getDirs(file) + "/arm/" + Utils.changeExtension(file.getName(), "odex")).exists()) return true;
                if (new File((Object)Utils.getDirs(file) + "/arm64/" + Utils.changeExtension(file.getName(), "odex")).exists()) return true;
                if (new File((Object)Utils.getDirs(file) + "/x86/" + Utils.changeExtension(file.getName(), "odex")).exists()) return true;
                boolean bl = new File((Object)Utils.getDirs(file) + "/x86_64/" + Utils.changeExtension(file.getName(), "odex")).exists();
                if (!bl) return false;
                return true;
            }
            if (new File((Object)Utils.getDirs(file) + "/oat/arm/" + string2).exists()) {
                return true;
            }
            if (new File((Object)Utils.getDirs(file) + "/oat/arm64/" + string2).exists()) return true;
            if (new File((Object)Utils.getDirs(file) + "/oat/x86/" + string2).exists()) return true;
            if (new File((Object)Utils.getDirs(file) + "/oat/x86_64/" + string2).exists()) return true;
            return false;
        }
        catch (Exception var2_4) {
            var2_4.printStackTrace();
            return false;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean isRebuildedOrOdex(String string, Context context) {
        boolean bl = true;
        Object object = null;
        try {
            byte[] arrby;
            PackageInfo packageInfo = listAppsFragment.getPkgMng().getPackageInfo(string, 64);
            try {
                arrby = packageInfo.signatures[0].toByteArray();
            }
            catch (Exception var6_6) {
                var6_6.printStackTrace();
                return false;
            }
            object = arrby;
            if (Utils.isOdex(packageInfo.applicationInfo.sourceDir)) {
                return bl;
            }
            boolean bl2 = listAppsFragment.getConfig().getBoolean(string, false);
            if (bl2) return bl;
        }
        catch (PackageManager.NameNotFoundException var4_8) {
            var4_8.printStackTrace();
        }
        if (object == null) {
            return false;
        }
        if (Base64.encode((byte[])object).replaceAll("\n", "").equals((Object)"MIIEqDCCA5CgAwIBAgIJAJNurL4H8gHfMA0GCSqGSIb3DQEBBQUAMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTAeFw0wODAyMjkwMTMzNDZaFw0zNTA3MTcwMTMzNDZaMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbTCCASAwDQYJKoZIhvcNAQEBBQADggENADCCAQgCggEBANaTGQTexgskse3HYuDZ2CU+Ps1s6x3i/waMqOi8qM1r03hupwqnbOYOuw+ZNVn/2T53qUPn6D1LZLjk/qLT5lbx4meoG7+yMLV4wgRDvkxyGLhG9SEVhvA4oU6Jwr44f46+z4/Kw9oe4zDJ6pPQp8PcSvNQIg1QCAcy4ICXF+5qBTNZ5qaU7Cyz8oSgpGbIepTYOzEJOmc3Li9kEsBubULxWBjf/gOBzAzURNps3cO4JFgZSAGzJWQTT7/emMkod0jb9WdqVA2BVMi7yge54kdVMxHEa5r3b97szI5p58ii0I54JiCUP5lyfTwE/nKZHZnfm644oLIXf6MdW2r+6R8CAQOjgfwwgfkwHQYDVR0OBBYEFEhZAFY9JyxGrhGGBaR0GawJyowRMIHJBgNVHSMEgcEwgb6AFEhZAFY9JyxGrhGGBaR0GawJyowRoYGapIGXMIGUMQswCQYDVQQGEwJVUzETMBEGA1UECBMKQ2FsaWZvcm5pYTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEQMA4GA1UEChMHQW5kcm9pZDEQMA4GA1UECxMHQW5kcm9pZDEQMA4GA1UEAxMHQW5kcm9pZDEiMCAGCSqGSIb3DQEJARYTYW5kcm9pZEBhbmRyb2lkLmNvbYIJAJNurL4H8gHfMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADggEBAHqvlozrUMRBBVEY0NqrrwFbinZaJ6cVosK0TyIUFf/azgMJWr+kLfcHCHJsIGnlw27drgQAvilFLAhLwn62oX6snb4YLCBOsVMR9FXYJLZW2+TcIkCRLXWG/oiVHQGo/rWuWkJgU134NDEFJCJGjDbiLCpe+ZTWHdcwauTJ9pUbo8EvHRkU3cYfGmLaLfgn9gP+pWA7LFQNvXwBnDa6sppCccEX31I828XzgXpJ4O+mDL1/dBd+ek8ZPUP0IgdyZm5MTYPhvVqGCHzzTy3sIeJFymwrsBbmg2OAUNLEMO6nwmocSdN2ClirfxqCzJOLSDE4QyS9BAH6EhY6UFcOaE0=")) return bl;
        return false;
    }

    public static boolean isServiceRunning(String string) {
        Iterator iterator = ((ActivityManager)listAppsFragment.getInstance().getSystemService("activity")).getRunningServices(Integer.MAX_VALUE).iterator();
        while (iterator.hasNext()) {
            if (!((ActivityManager.RunningServiceInfo)iterator.next()).service.getClassName().equals((Object)string)) continue;
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public static boolean isServicesCache() {
        if (new File("/data/dalvik-cache/arm/system@framework@services.jar@classes.dex").exists() || new File("/data/dalvik-cache/arm64/system@framework@services.jar@classes.dex").exists() || new File("/data/dalvik-cache/x86/system@framework@services.jar@classes.dex").exists() || new File("/data/dalvik-cache/x86_64/system@framework@services.jar@classes.dex").exists() || new File("/data/dalvik-cache/oat/arm/system@framework@services.jar@classes.dex").exists() || new File("/data/dalvik-cache/oat/arm64/system@framework@services.jar@classes.dex").exists() || new File("/data/dalvik-cache/oat/x86/system@framework@services.jar@classes.dex").exists() || new File("/data/dalvik-cache/oat/x86_64/system@framework@services.jar@classes.dex").exists()) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static boolean isWithFramework() {
        if (listAppsFragment.api >= 23) {
            return false;
        }
        Utils utils = new Utils("");
        String[] arrstring = new String[]{listAppsFragment.dalvikruncommandWithFramework + ".checkWithFramework 123"};
        String string = utils.cmdRoot(arrstring);
        listAppsFragment.startUnderRoot = false;
        if (string.contains((CharSequence)"withoutFramework")) return false;
        if (listAppsFragment.errorOutput.contains((CharSequence)"java.lang.ClassNotFoundException:")) return false;
        System.out.println("WithFramework support");
        return true;
    }

    public static boolean isXposedEnabled() {
        return false;
    }

    public static long javaToDosTime(long l) {
        Date date = new Date(l);
        int n = 1900 + date.getYear();
        if (n < 1980) {
            return 2162688;
        }
        return n - 1980 << 25 | 1 + date.getMonth() << 21 | date.getDate() << 16 | date.getHours() << 11 | date.getMinutes() << 5 | date.getSeconds() >> 1;
    }

    public static void kill(String string) {
        if (!listAppsFragment.startUnderRoot.booleanValue()) {
            Utils.killAll(string);
            return;
        }
        Utils.killAll(string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean killAll(String string) {
        String[] arrstring;
        ArrayList arrayList;
        int n;
        if (listAppsFragment.startUnderRoot.booleanValue()) {
            String[] arrstring2 = new String[]{listAppsFragment.toolfilesdir + "/busybox", "ps", "grep", string};
            String string2 = Utils.cmdParam(arrstring2);
            if (string2.startsWith("~")) {
                if (string2.startsWith("~")) {
                    String[] arrstring3 = new String[]{listAppsFragment.toolfilesdir + "/busybox", "ps"};
                    string2 = Utils.cmdParam(arrstring3);
                }
                if (string2.startsWith("~")) {
                    string2 = Utils.cmdParam("busybox", "ps");
                }
                if (string2.startsWith("~")) {
                    string2 = Utils.cmdParam("toolbox", "ps");
                }
            }
            if (string2.equals((Object)"~")) return false;
            if (string2.equals((Object)"")) return false;
            arrstring = string2.split("\n");
            arrayList = new ArrayList();
            if (arrstring.length <= 1) return false;
            n = arrstring.length;
        } else {
            Utils utils = new Utils("");
            String[] arrstring4 = new String[]{listAppsFragment.toolfilesdir + "/busybox ps |grep '" + string + "'"};
            String string3 = utils.cmdRoot(arrstring4);
            if (string3.startsWith("~")) {
                Utils.exitRoot();
                try {
                    listAppsFragment.getSu();
                }
                catch (IOException var18_4) {
                    var18_4.printStackTrace();
                }
                Utils utils2 = new Utils("");
                String[] arrstring5 = new String[]{listAppsFragment.toolfilesdir + "/busybox ps"};
                string3 = utils2.cmdRoot(arrstring5);
                if (string3.startsWith("~")) {
                    string3 = new Utils("").cmdRoot("busybox ps");
                }
                if (string3.startsWith("~")) {
                    string3 = new Utils("").cmdRoot("ps");
                }
            }
            if (string3.equals((Object)"~")) return false;
            if (string3.equals((Object)"")) return false;
            String[] arrstring6 = string3.split("\n");
            ArrayList arrayList2 = new ArrayList();
            if (arrstring6.length <= 1) return false;
            for (String string4 : arrstring6) {
                if (!string4.contains((CharSequence)string) || string4.contains((CharSequence)(string + "."))) continue;
                String[] arrstring7 = (string4 + "\n").trim().split("\\s+");
                try {
                    String string5 = arrstring7[0];
                    arrayList2.add((Object)string5);
                    System.out.println("Found pid: " + string5 + " for " + string);
                    continue;
                }
                catch (Exception var15_12) {
                    System.out.println("Error with regex! " + (Object)var15_12);
                }
            }
            if (arrayList2.size() <= 0) return false;
            Iterator iterator = arrayList2.iterator();
            while (iterator.hasNext()) {
                String string6 = (String)iterator.next();
                System.out.println("Kill: " + string6 + " for " + string);
                if (string6.equals((Object)"0")) continue;
                Utils utils3 = new Utils("");
                String[] arrstring8 = new String[]{"kill -9 " + string6};
                utils3.cmdRoot(arrstring8);
            }
            return true;
        }
        for (int i = 0; i < n; ++i) {
            String string7 = arrstring[i];
            if (!string7.contains((CharSequence)string) || string7.contains((CharSequence)(string + "."))) continue;
            String[] arrstring9 = (string7 + "\n").trim().split("\\s+");
            try {
                String string8 = arrstring9[0];
                arrayList.add((Object)string8);
                System.out.println("Found pid: " + string8 + " for " + string);
                continue;
            }
            catch (Exception var33_26) {
                System.out.println("Error with regex! " + (Object)var33_26);
            }
        }
        if (arrayList.size() <= 0) return false;
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            String string9 = (String)iterator.next();
            System.out.println("Kill: " + string9 + " for " + string);
            if (string9.equals((Object)"0")) continue;
            Utils.cmdParam("kill", "-9", string9);
        }
        return true;
    }

    public static void market_billing_services(final boolean bl) {
        if (listAppsFragment.su) {
            new Thread(new Runnable(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    new ArrayList();
                    PackageInfo packageInfo = Utils.getPkgInfo("com.android.vending", 516);
                    boolean bl2 = false;
                    if (packageInfo == null) return;
                    if (packageInfo.services == null || packageInfo.services.length == 0) return;
                    int n = 0;
                    do {
                        if (n >= packageInfo.services.length) {
                            if (!bl2 && bl) {
                                new Utils("").cmdRoot("pm enable 'com.android.vending/com.google.android.finsky.billing.iab.InAppBillingService'");
                                new Utils("").cmdRoot("pm enable 'com.android.vending/com.google.android.finsky.billing.iab.FirstPartyInAppBillingService'");
                                new Utils("").cmdRoot("pm enable 'com.android.vending/com.google.android.finsky.billing.iab.MarketBillingService'");
                            }
                            if (listAppsFragment.frag == null) return;
                            listAppsFragment.frag.runToMain(new Runnable(){

                                public void run() {
                                    try {
                                        if (listAppsFragment.menu_adapt != null) {
                                            listAppsFragment.removeDialogLP((int)11);
                                            listAppsFragment.menu_adapt.notifyDataSetChanged();
                                        }
                                        return;
                                    }
                                    catch (Exception var1_1) {
                                        var1_1.printStackTrace();
                                        return;
                                    }
                                }
                            });
                            return;
                        }
                        try {
                            if (!bl) {
                                if ((packageInfo.services[n].name.endsWith("InAppBillingService") || packageInfo.services[n].name.endsWith("MarketBillingService")) && listAppsFragment.getPkgMng().getComponentEnabledSetting(new ComponentName("com.android.vending", packageInfo.services[n].name)) != 2) {
                                    Utils utils = new Utils("");
                                    String[] arrstring = new String[]{"pm disable 'com.android.vending/" + packageInfo.services[n].name + "'"};
                                    utils.cmdRoot(arrstring);
                                    bl2 = true;
                                }
                            } else if ((packageInfo.services[n].name.endsWith("InAppBillingService") || packageInfo.services[n].name.endsWith("MarketBillingService")) && listAppsFragment.getPkgMng().getComponentEnabledSetting(new ComponentName("com.android.vending", packageInfo.services[n].name)) != 1) {
                                Utils utils = new Utils("");
                                String[] arrstring = new String[]{"pm enable 'com.android.vending/" + packageInfo.services[n].name + "'"};
                                utils.cmdRoot(arrstring);
                                bl2 = true;
                            }
                        }
                        catch (Exception var8_4) {
                            var8_4.printStackTrace();
                        }
                        ++n;
                    } while (true);
                }

            }).start();
        }
    }

    /*
     * Exception decompiling
     */
    public static void market_billing_services_to_main_stream(boolean var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredWhile.transformStructuredChildren(StructuredWhile.java:50)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void market_licensing_services(final boolean bl) {
        if (listAppsFragment.su) {
            new Thread(new Runnable(){

                /*
                 * Enabled aggressive block sorting
                 * Enabled unnecessary exception pruning
                 * Enabled aggressive exception aggregation
                 */
                public void run() {
                    new ArrayList();
                    PackageInfo packageInfo = Utils.getPkgInfo("com.android.vending", 516);
                    boolean bl2 = false;
                    if (packageInfo == null) return;
                    if (packageInfo.services == null || packageInfo.services.length == 0) return;
                    int n = 0;
                    do {
                        if (n >= packageInfo.services.length) {
                            if (!bl2 && bl) {
                                new Utils("").cmdRoot("pm enable 'com.android.vending/com.google.android.finsky.services.LicensingService'");
                            }
                            if (listAppsFragment.frag == null) return;
                            listAppsFragment.frag.runToMain(new Runnable(){

                                public void run() {
                                    try {
                                        if (listAppsFragment.menu_adapt != null) {
                                            listAppsFragment.removeDialogLP((int)11);
                                            listAppsFragment.menu_adapt.notifyDataSetChanged();
                                        }
                                        return;
                                    }
                                    catch (Exception var1_1) {
                                        var1_1.printStackTrace();
                                        return;
                                    }
                                }
                            });
                            return;
                        }
                        try {
                            if (!bl) {
                                if (packageInfo.services[n].name.endsWith("LicensingService") && listAppsFragment.getPkgMng().getComponentEnabledSetting(new ComponentName("com.android.vending", packageInfo.services[n].name)) != 2) {
                                    bl2 = true;
                                    Utils utils = new Utils("");
                                    String[] arrstring = new String[]{"pm disable 'com.android.vending/" + packageInfo.services[n].name + "'"};
                                    utils.cmdRoot(arrstring);
                                }
                            } else if (packageInfo.services[n].name.endsWith("LicensingService") && listAppsFragment.getPkgMng().getComponentEnabledSetting(new ComponentName("com.android.vending", packageInfo.services[n].name)) != 1) {
                                bl2 = true;
                                Utils utils = new Utils("");
                                String[] arrstring = new String[]{"pm enable 'com.android.vending/" + packageInfo.services[n].name + "'"};
                                utils.cmdRoot(arrstring);
                            }
                        }
                        catch (Exception var6_8) {
                            var6_8.printStackTrace();
                        }
                        ++n;
                    } while (true);
                }

            }).start();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static void market_licensing_services_to_main_stream(boolean var0) {
        if (!listAppsFragment.su) return;
        new ArrayList();
        var2_1 = Utils.getPkgInfo("com.android.vending", 516);
        if (var2_1 == null || var2_1.services == null || var2_1.services.length == 0) return;
        var3_2 = 0;
lbl6: // 2 sources:
        if (var3_2 >= var2_1.services.length) return;
        if (var0) ** GOTO lbl14
        try {
            if (!var2_1.services[var3_2].name.endsWith("LicensingService") || listAppsFragment.getPkgMng().getComponentEnabledSetting(new ComponentName("com.android.vending", var2_1.services[var3_2].name)) == 2) ** GOTO lbl21
            var8_3 = new Utils("");
            var9_4 = new String[]{"pm disable 'com.android.vending/" + var2_1.services[var3_2].name + "'", "skipOut"};
            var8_3.cmdRoot(var9_4);
lbl14: // 1 sources:
            if (!var2_1.services[var3_2].name.endsWith("LicensingService") || listAppsFragment.getPkgMng().getComponentEnabledSetting(new ComponentName("com.android.vending", var2_1.services[var3_2].name)) == 1) ** GOTO lbl21
            var5_5 = new Utils("");
            var6_7 = new String[]{"pm enable 'com.android.vending/" + var2_1.services[var3_2].name + "'", "skipOut"};
            var5_5.cmdRoot(var6_7);
        }
        catch (Exception var4_6) {
            var4_6.printStackTrace();
        }
lbl21: // 5 sources:
        ++var3_2;
        ** GOTO lbl6
    }

    public static boolean onMainThread() {
        if (Looper.myLooper() != null && Looper.myLooper() == Looper.getMainLooper()) {
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean pattern_checker(Activity activity) {
        String string = activity.getApplicationInfo().sourceDir;
        System.out.println(string);
        Object object = null;
        try {
            object = activity.getPackageManager().getPackageInfo((String)activity.getPackageName(), (int)64).signatures[0].toByteArray();
            System.out.println();
        }
        catch (PackageManager.NameNotFoundException var3_5) {
            var3_5.printStackTrace();
        }
        boolean bl = Base64.encode((byte[])object).replaceAll("\n", "").equals((Object)"MIIDDTCCAfWgAwIBAgIEeR8eUDANBgkqhkiG9w0BAQsFADA3MQswCQYDVQQGEwJVUzEQMA4GA1UEChMHQW5kcm9pZDEWMBQGA1UEAxMNQW5kcm9pZCBEZWJ1ZzAeFw0xMTEyMDgwNjA1MTBaFw00MTExMzAwNjA1MTBaMDcxCzAJBgNVBAYTAlVTMRAwDgYDVQQKEwdBbmRyb2lkMRYwFAYDVQQDEw1BbmRyb2lkIERlYnVnMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAhENqFp22Dq9M/CEU4on3/xGfoWggUk4tahTdC/okxdVO/nB27odddvB+zDiMSq+mGFprWxk31pzu+W31pbdq4tnBF6aqzhLanAjxVoeuqNUDzXfqNhxjQDJjZ9Q9zntEHNllIkfJclYyADf1GHjQs9vpgo58EXQ4Wt8REG9P+8My5ENmVkfTA3L7yryyTnplRn7d+jVtIcJEKY0s/kCFfRMNJnM2vYYWGpXrmEJFMNPtjvPGvnNgMojHLgWqY7z7foplBjGfEItX/huYZqp7+ZaGWyrksXHStEUXUa7TJJiW++R4e4VL6jIDwTHGOAgYaVA/ZarfLquQhXP28vBNhwIDAQABoyEwHzAdBgNVHQ4EFgQUNrZ//EPQx9WdAor2L5dvsy6i9eYwDQYJKoZIhvcNAQELBQADggEBAH09ZytGQmSrbGNjbCMnuZ+UuKOP+nN5j0U0hbMisC+2rcox36S23hVDPEc7rcBMo/Aep4kY/CZCO9UnRVP5NG3YugQU2mwimM2po4pZZbOBCDx4dEjA4ymJpKlS4fEPQ1qp5p9um8wmMVg5Yl5y9dGpxNF/USDW5jq+H8SBhfcrro+m4V+G/jPGWSN/0QwJpb0dmsD2MLgw7/HyJPnymvSEzom6e7Oe4aJDzOKuRM5hrfvsNyH+WTq+f+IElEVMg1zwo0JHhFTppxEFROPHTYO2FjMdrA26KdPcLTS07pzpP00/0n+4R7SPoAHzMBptlvNZws9KvaQEiOc0ObXhjL0=");
        boolean bl2 = false;
        if (!bl) return bl2;
        return true;
    }

    public static String readLine(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        int n;
        while ((n = inputStream.read()) >= 0) {
            if (n == 10) {
                return new String(byteArrayOutputStream.toByteArray(), "UTF-8");
            }
            byteArrayOutputStream.write(n);
        }
        return null;
    }

    public static JSONObject readXposedParamBoolean() throws JSONException {
        return new JSONObject(Utils.read_from_file(new File("/data/lp/xposed")));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String read_from_file(File file) {
        RandomAccessFile randomAccessFile;
        byte[] arrby = new byte[(int)file.length()];
        try {
            randomAccessFile = new RandomAccessFile(file, "r");
        }
        catch (Exception var3_3) {}
        try {
            randomAccessFile.seek(0);
            randomAccessFile.read(arrby);
            randomAccessFile.close();
        }
        catch (Exception var3_5) {}
        return new String(arrby);
        {
            void var3_4;
            var3_4.printStackTrace();
            return new String(arrby);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void reboot() {
        if (!listAppsFragment.startUnderRoot.booleanValue()) {
            try {
                new Utils("").cmdRoot("reboot");
            }
            catch (Exception var13) {
                var13.printStackTrace();
            }
            try {
                new Utils("").cmdRoot("/system/bin/reboot");
            }
            catch (Exception var14_1) {
                var14_1.printStackTrace();
            }
            try {
                new Utils("").cmdRoot("/system/xbin/reboot");
            }
            catch (Exception var15_2) {
                var15_2.printStackTrace();
            }
            try {
                new Utils("").cmdRoot("busybox reboot");
            }
            catch (Exception var16_3) {
                var16_3.printStackTrace();
            }
            try {
                Utils.cmd("reboot");
            }
            catch (Exception var17_4) {
                var17_4.printStackTrace();
            }
            try {
                Utils.run_all("reboot");
            }
            catch (Exception var18_5) {
                var18_5.printStackTrace();
            }
            try {
                listAppsFragment.patchAct.runOnUiThread(new Runnable(){

                    public void run() {
                        Toast.makeText((Context)listAppsFragment.getInstance(), (CharSequence)Utils.getText(2131165689), (int)1).show();
                    }
                });
            }
            catch (Exception var19_6) {
                var19_6.printStackTrace();
            }
            new Utils("w").waitLP(5000);
            try {
                Utils.run_all((Object)listAppsFragment.getInstance().getFilesDir() + "/reboot");
                return;
            }
            catch (Exception var20_7) {
                var20_7.printStackTrace();
                return;
            }
        }
        try {
            Utils.cmdParam("reboot");
        }
        catch (Exception var0_10) {
            var0_10.printStackTrace();
        }
        try {
            Utils.cmdParam("/system/bin/reboot");
        }
        catch (Exception var1_11) {
            var1_11.printStackTrace();
        }
        try {
            Utils.cmdParam("/system/xbin/reboot");
        }
        catch (Exception var2_12) {
            var2_12.printStackTrace();
        }
        try {
            Utils.cmdParam("busybox reboot");
        }
        catch (Exception var3_13) {
            var3_13.printStackTrace();
        }
        try {
            Utils.cmd("reboot");
        }
        catch (Exception var4_14) {
            var4_14.printStackTrace();
        }
        try {
            Utils.run_all_no_root("reboot");
        }
        catch (Exception var5_15) {
            var5_15.printStackTrace();
        }
        try {
            String[] arrstring = new String[]{listAppsFragment.toolfilesdir + "/reboot"};
            Utils.run_all_no_root(arrstring);
            return;
        }
        catch (Exception var6_9) {
            var6_9.printStackTrace();
            return;
        }
    }

    /*
     * Exception decompiling
     */
    public static boolean remount(String var0_1, String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String removeExtension(String string) {
        String string2 = "";
        if (string != null) {
            String[] arrstring = string.split("\\.");
            for (int i = 0; i < arrstring.length; ++i) {
                if (i < -2 + arrstring.length) {
                    string2 = string2 + arrstring[i] + ".";
                    continue;
                }
                string2 = string2 + arrstring[i];
                break;
            }
        }
        return string2;
    }

    /*
     * Exception decompiling
     */
    public static void removePkgFromSystem(String var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [1[TRYBLOCK]], but top level block is 10[FORLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static int replaceString(String var0_1, String var1, String var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 16[WHILELOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static int replaceStringIds(String var0_1, String[] var1, boolean var2_3, String[] var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 21[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static int replaceStrings(String var0_1, String[] var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 18[WHILELOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static String rework(String string) {
        if (string.contains((CharSequence)"52")) {
            string = string.replaceAll("52", "f2");
        }
        if (string.contains((CharSequence)"53")) {
            string = string.replaceAll("53", "f3");
        }
        if (string.contains((CharSequence)"54")) {
            string = string.replaceAll("54", "f4");
        }
        if (string.contains((CharSequence)"55")) {
            string = string.replaceAll("55", "f2");
        }
        if (string.contains((CharSequence)"59")) {
            string = string.replaceAll("59", "f5");
        }
        if (string.toUpperCase().contains((CharSequence)"5A")) {
            string = string.toUpperCase().replaceAll("5A", "F6");
        }
        if (string.toUpperCase().contains((CharSequence)"5B")) {
            string = string.toUpperCase().replaceAll("5B", "F7");
        }
        if (string.toUpperCase().contains((CharSequence)"5C")) {
            string = string.toUpperCase().replaceAll("5C", "F5");
        }
        if (string.toUpperCase().contains((CharSequence)"5D")) {
            string = string.toUpperCase().replaceAll("5D", "F5");
        }
        if (string.contains((CharSequence)"74")) {
            string = string.replaceAll("74", "f9");
        }
        if (string.toUpperCase().contains((CharSequence)"6E")) {
            string = string.toUpperCase().replaceAll("6E", "F8");
        }
        return string;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void run_all(String string) {
        try {
            if (listAppsFragment.su && !listAppsFragment.checktools) {
                ArrayList arrayList = new ArrayList();
                arrayList.clear();
                arrayList.add((Object)(listAppsFragment.toolfilesdir + "/busybox"));
                if (Utils.exists("/system/bin/failsafe/toolbox")) {
                    arrayList.add((Object)"/system/bin/failsafe/toolbox");
                }
                listAppsFragment.errorOutput = "";
                Utils utils = new Utils("");
                String[] arrstring = new String[]{"busybox chmod 777 " + listAppsFragment.toolfilesdir + "/busybox"};
                utils.cmdRoot(arrstring);
                if (listAppsFragment.errorOutput.equals((Object)"")) {
                    arrayList.add((Object)"busybox");
                }
                listAppsFragment.errorOutput = "";
                Utils utils2 = new Utils("");
                String[] arrstring2 = new String[]{"toolbox chmod 777 " + listAppsFragment.toolfilesdir + "/busybox"};
                utils2.cmdRoot(arrstring2);
                if (listAppsFragment.errorOutput.equals((Object)"")) {
                    arrayList.add((Object)"toolbox");
                } else {
                    System.out.println("skip toolbox in tools");
                }
                listAppsFragment.tools = new String[arrayList.size()];
                listAppsFragment.tools = (String[])arrayList.toArray(listAppsFragment.tools);
                listAppsFragment.checktools = true;
            }
            if (!listAppsFragment.su) return;
            {
                String[] arrstring = new String[1 + listAppsFragment.tools.length];
                int n = 1;
                arrstring[0] = string;
                String[] arrstring3 = listAppsFragment.tools;
                int n2 = arrstring3.length;
                for (int i = 0; i < n2; ++n, ++i) {
                    String string2 = arrstring3[i];
                    arrstring[n] = string2 + " " + string;
                }
                new Utils("").cmdRoot(arrstring);
                return;
            }
        }
        catch (Exception var1_12) {
            var1_12.printStackTrace();
        }
    }

    /*
     * Exception decompiling
     */
    public static /* varargs */ void run_all_no_root(String ... var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Backjump on non jumping statement [] lbl47 : TryStatement: try { 2[TRYBLOCK]

        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:44)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner$1.call(Cleaner.java:22)
        // org.benf.cfr.reader.util.graph.GraphVisitorDFS.process(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.Cleaner.removeUnreachableCode(Cleaner.java:54)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.op3rewriters.RemoveDeterministicJumps.apply(RemoveDeterministicJumps.java:35)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:507)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static boolean saveXposedParamBoolean(String var0_1, boolean var1, boolean var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 13[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean save_text_to_end_file(File file, String string) {
        long l;
        int n;
        RandomAccessFile randomAccessFile;
        long l2;
        try {
            if (!file.exists()) {
                Utils.getDirs(file).mkdirs();
                file.createNewFile();
            }
            System.out.println("...rrunning my app...");
            randomAccessFile = new RandomAccessFile(file, "rw");
        }
        catch (Exception var2_6) {}
        try {
            l2 = file.length();
            randomAccessFile.seek(file.length());
            randomAccessFile.write(string.getBytes());
            System.out.println("...file length..." + randomAccessFile.length());
            randomAccessFile.close();
            l = file.length();
            n = string.length();
        }
        catch (Exception var2_8) {}
        if (l != l2 + (long)n) {
            return false;
        }
        return true;
        {
            void var2_7;
            var2_7.printStackTrace();
            return false;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean save_text_to_end_file_from_file(File var0_1, File var1) {
        System.out.println("...rrunning my app...");
        var3_2 = new RandomAccessFile(var0_1, "rw");
        var4_3 = new RandomAccessFile(var1, "r");
        try {
            var0_1.length();
            var3_2.seek(var0_1.length());
            try {
                var3_2.write("#Lucky Patcher block Ads start#\n".getBytes());
                var8_4 = new byte[4096];
                while ((var9_5 = var4_3.read(var8_4)) > 0) {
                    var3_2.write(var8_4, 0, var9_5);
                }
                var3_2.write("#Lucky Patcher block Ads finish#\n\n\n\r\n".getBytes());
                var4_3.close();
            }
            catch (IOException var7_6) {
                var7_6.printStackTrace();
                return false;
            }
            var3_2.close();
            return true;
        }
        catch (Exception var2_10) {}
        catch (Exception var2_7) {}
        ** GOTO lbl-1000
        catch (Exception var2_9) {}
        {
        }
lbl-1000: // 3 sources:
        {
            var2_8.printStackTrace();
            return false;
        }
    }

    /*
     * Exception decompiling
     */
    public static boolean save_text_to_file(File var0_1, String var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 4[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static boolean sendFromRoot(String string) {
        System.out.println(string);
        return false;
    }

    public static boolean sendFromRootCP(String string) {
        System.out.println(string);
        return false;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static final void setIcon(int n) {
        switch (n) {
            default: {
                return;
            }
            case 0: {
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 1, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 2, 1);
                try {
                    if (listAppsFragment.frag == null) return;
                    if (listAppsFragment.api <= 10) return;
                    listAppsFragment.frag.getActivity().getActionBar().setIcon(2130837544);
                    return;
                }
                catch (Exception var16_1) {
                    return;
                }
            }
            case 1: {
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 1, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 2, 1);
                try {
                    if (listAppsFragment.frag == null) return;
                    if (listAppsFragment.api <= 10) return;
                    listAppsFragment.frag.getActivity().getActionBar().setIcon(2130903046);
                    return;
                }
                catch (Exception var14_2) {
                    return;
                }
            }
            case 2: {
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 1, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 2, 1);
                try {
                    if (listAppsFragment.frag == null) return;
                    if (listAppsFragment.api <= 10) return;
                    listAppsFragment.frag.getActivity().getActionBar().setIcon(2130903047);
                    return;
                }
                catch (Exception var12_3) {
                    return;
                }
            }
            case 3: {
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 1, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 2, 1);
                try {
                    if (listAppsFragment.frag == null) return;
                    if (listAppsFragment.api <= 10) return;
                    listAppsFragment.frag.getActivity().getActionBar().setIcon(2130903048);
                    return;
                }
                catch (Exception var10_4) {
                    return;
                }
            }
            case 4: {
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 1, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 2, 1);
                try {
                    if (listAppsFragment.frag == null) return;
                    if (listAppsFragment.api <= 10) return;
                    listAppsFragment.frag.getActivity().getActionBar().setIcon(2130903049);
                    return;
                }
                catch (Exception var8_5) {
                    return;
                }
            }
            case 5: {
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 1, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 2, 1);
                try {
                    if (listAppsFragment.frag == null) return;
                    if (listAppsFragment.api <= 10) return;
                    listAppsFragment.frag.getActivity().getActionBar().setIcon(2130903050);
                    return;
                }
                catch (Exception var6_6) {
                    return;
                }
            }
            case 6: {
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 2, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 1, 1);
                listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 2, 1);
                try {
                    if (listAppsFragment.frag == null) return;
                    if (listAppsFragment.api <= 10) return;
                    listAppsFragment.frag.getActivity().getActionBar().setIcon(2130903050);
                    return;
                }
                catch (Exception exception) {
                    return;
                }
            }
            case 7: 
        }
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Original"), 2, 1);
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-Flint"), 2, 1);
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-2"), 2, 1);
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-3"), 2, 1);
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-4"), 2, 1);
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-5"), 2, 1);
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-6"), 2, 1);
        listAppsFragment.getPkgMng().setComponentEnabledSetting(new ComponentName(listAppsFragment.getInstance(), "com.android.vending.billing.InAppBillingService.LOCK.MainActivity-7"), 1, 1);
        try {
            if (listAppsFragment.frag == null) return;
            if (listAppsFragment.api <= 10) return;
            listAppsFragment.frag.getActivity().getActionBar().setIcon(2130903050);
            return;
        }
        catch (Exception var2_8) {
            return;
        }
        catch (NoSuchMethodError var1_9) {
            return;
        }
        catch (NoSuchMethodError noSuchMethodError) {
            return;
        }
        catch (NoSuchMethodError noSuchMethodError2) {
            return;
        }
        catch (NoSuchMethodError noSuchMethodError3) {
            return;
        }
        catch (NoSuchMethodError noSuchMethodError4) {
            return;
        }
        catch (NoSuchMethodError noSuchMethodError5) {
            return;
        }
        catch (NoSuchMethodError noSuchMethodError6) {
            return;
        }
        catch (NoSuchMethodError noSuchMethodError7) {
            return;
        }
    }

    public static void setOwnerDir(String string, String string2, String string3, boolean bl) {
        if (new File(string2).exists()) {
            String[] arrstring = string2.split(File.separator);
            String string4 = "/";
            for (int i = 0; i < arrstring.length; ++i) {
                if (!arrstring[i].equals((Object)"")) {
                    string4 = string4 + arrstring[i];
                }
                if (string4.startsWith(string) || (string4 + "/").startsWith(string)) {
                    if (bl) {
                        Utils.cmdParam("chown", string3, string4);
                        String[] arrstring2 = new String[]{"chown", string3.replace((CharSequence)":", (CharSequence)"."), string4};
                        Utils.cmdParam(arrstring2);
                    }
                    bl = true;
                }
                if (arrstring[i].equals((Object)"")) continue;
                string4 = string4 + "/";
            }
        }
    }

    public static void setPermissionDir(String string, String string2, String string3, boolean bl) {
        if (new File(string2).exists()) {
            String[] arrstring = string2.split(File.separator);
            String string4 = "/";
            for (int i = 0; i < arrstring.length; ++i) {
                if (!arrstring[i].equals((Object)"")) {
                    string4 = string4 + arrstring[i];
                }
                if (string4.startsWith(string) || (string4 + "/").startsWith(string)) {
                    if (bl) {
                        Utils.cmdParam("chmod", string3, string4);
                    }
                    bl = true;
                }
                if (arrstring[i].equals((Object)"")) continue;
                string4 = string4 + "/";
            }
        }
    }

    /*
     * Exception decompiling
     */
    public static int setStringIds(String var0_1, byte[][] var1, boolean var2_3, byte var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 23[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void setTitle(AlertDialog.Builder builder, int n, String string) {
        LinearLayout linearLayout = (LinearLayout)View.inflate((Context)listAppsFragment.frag.getContext(), (int)2130968606, (ViewGroup)null);
        TextView textView = (TextView)linearLayout.findViewById(2131558429);
        ((ImageView)linearLayout.findViewById(2131558428)).setImageDrawable(listAppsFragment.getRes().getDrawable(n));
        textView.setText((CharSequence)string);
        builder.setCustomTitle((View)linearLayout);
    }

    public static String sha1withrsa_sign(String string) {
        String string2 = "";
        try {
            PrivateKey privateKey = KeyPairGenerator.getInstance((String)"RSA").generateKeyPair().getPrivate();
            java.security.Signature signature = java.security.Signature.getInstance((String)"SHA1withRSA");
            signature.initSign(privateKey);
            signature.update(string.getBytes());
            byte[] arrby = signature.sign();
            string2 = Base64.encode(arrby);
            System.out.println("b64: " + Base64.encode(arrby));
            System.out.println("Signature: " + new String(arrby));
            return string2;
        }
        catch (NoSuchAlgorithmException var4_5) {
            var4_5.printStackTrace();
            return string2;
        }
        catch (SignatureException var3_6) {
            var3_6.printStackTrace();
            return string2;
        }
        catch (InvalidKeyException var2_7) {
            var2_7.printStackTrace();
            return string2;
        }
    }

    public static void showDialog(Dialog dialog) {
        try {
            if (listAppsFragment.patchAct != null && !listAppsFragment.patchAct.isFinishing()) {
                dialog.show();
            }
            return;
        }
        catch (Exception var1_1) {
            var1_1.printStackTrace();
            return;
        }
    }

    public static void showDialogCustomYes(String string, String string2, String string3, DialogInterface.OnClickListener onClickListener, DialogInterface.OnClickListener onClickListener2, DialogInterface.OnCancelListener onCancelListener) {
        try {
            if (listAppsFragment.patchAct != null && !listAppsFragment.patchAct.isFinishing()) {
                Dialog dialog = new AlertDlg((Context)listAppsFragment.frag.getContext()).setTitle(string).setMessage(string2).setIcon(2130837547).setPositiveButton(string3, onClickListener).setNegativeButton(Utils.getText(2131165607), onClickListener2).setOnCancelListener(onCancelListener).create();
                Utils.showDialog(dialog);
                dialog.findViewById(16908299);
            }
            return;
        }
        catch (Exception var6_7) {
            var6_7.printStackTrace();
            return;
        }
    }

    public static void showDialogCustomYesNo(String string, String string2, String string3, DialogInterface.OnClickListener onClickListener, String string4, DialogInterface.OnClickListener onClickListener2, DialogInterface.OnCancelListener onCancelListener) {
        try {
            if (listAppsFragment.patchAct != null && !listAppsFragment.patchAct.isFinishing()) {
                Dialog dialog = new AlertDlg((Context)listAppsFragment.frag.getContext()).setTitle(string).setMessage(string2).setIcon(2130837547).setPositiveButton(string3, onClickListener).setNegativeButton(string4, onClickListener2).setOnCancelListener(onCancelListener).create();
                Utils.showDialog(dialog);
                dialog.findViewById(16908299);
            }
            return;
        }
        catch (Exception var7_8) {
            var7_8.printStackTrace();
            return;
        }
    }

    public static void showDialogYesNo(String string, String string2, DialogInterface.OnClickListener onClickListener, DialogInterface.OnClickListener onClickListener2, DialogInterface.OnCancelListener onCancelListener) {
        try {
            if (listAppsFragment.patchAct != null && !listAppsFragment.patchAct.isFinishing()) {
                Dialog dialog = new AlertDlg((Context)listAppsFragment.frag.getContext()).setTitle(string).setMessage(string2).setIcon(2130837547).setPositiveButton(Utils.getText(2131165187), onClickListener).setNegativeButton(Utils.getText(2131165607), onClickListener2).setOnCancelListener(onCancelListener).create();
                Utils.showDialog(dialog);
                dialog.findViewById(16908299);
            }
            return;
        }
        catch (Exception var5_6) {
            var5_6.printStackTrace();
            return;
        }
    }

    public static void showDialogYesNoAndCheckBox(String string, String string2, String string3, CompoundButton.OnCheckedChangeListener onCheckedChangeListener, boolean bl, DialogInterface.OnClickListener onClickListener, DialogInterface.OnClickListener onClickListener2, DialogInterface.OnCancelListener onCancelListener) {
        try {
            if (listAppsFragment.patchAct != null && !listAppsFragment.patchAct.isFinishing()) {
                Dialog dialog = new AlertDlg((Context)listAppsFragment.frag.getContext()).setTitle(string).setMessage(string2).setIcon(2130837547).setPositiveButton(Utils.getText(2131165187), onClickListener).setNegativeButton(Utils.getText(2131165607), onClickListener2).setOnCancelListener(onCancelListener).setCheckBox(string3, onCheckedChangeListener, bl).create();
                Utils.showDialog(dialog);
                dialog.findViewById(16908299);
            }
            return;
        }
        catch (Exception var8_9) {
            var8_9.printStackTrace();
            return;
        }
    }

    public static void showMessage(final Activity activity, final String string, final String string2) {
        activity.runOnUiThread(new Runnable(){

            public void run() {
                AlertDlg alertDlg = new AlertDlg((Context)activity);
                alertDlg.setTitle(string);
                alertDlg.setMessage(string2);
                alertDlg.setPositiveButton(2131165633, null);
                try {
                    Utils.showDialog(alertDlg.create());
                    return;
                }
                catch (Exception var5_2) {
                    var5_2.printStackTrace();
                    return;
                }
            }
        });
    }

    public static void showSystemWindow(String string, String string2, View.OnClickListener onClickListener, View.OnClickListener onClickListener2) {
        final WindowManager windowManager = (WindowManager)listAppsFragment.getInstance().getSystemService("window");
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.gravity = 17;
        layoutParams.type = 2003;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.alpha = 1.0f;
        layoutParams.packageName = listAppsFragment.getInstance().getPackageName();
        layoutParams.buttonBrightness = 1.0f;
        layoutParams.windowAnimations = 16973826;
        View view = View.inflate((Context)listAppsFragment.getInstance(), (int)2130968631, (ViewGroup)null);
        Button button = (Button)view.findViewById(2131558443);
        Button button2 = (Button)view.findViewById(2131558441);
        TextView textView = (TextView)view.findViewById(2131558604);
        ((TextView)view.findViewById(2131558478)).setText((CharSequence)string);
        textView.setText((CharSequence)string2);
        button.setOnClickListener(onClickListener);
        button2.setOnClickListener(onClickListener2);
        button.setOnKeyListener(new View.OnKeyListener(){

            public boolean onKey(View view, int n, KeyEvent keyEvent) {
                System.out.println("keyCode " + n);
                if (n == 4) {
                    windowManager.removeView(view.getRootView());
                }
                return false;
            }
        });
        windowManager.addView(view, (ViewGroup.LayoutParams)layoutParams);
    }

    public static void showSystemWindowOk(String string, String string2) {
        final WindowManager windowManager = (WindowManager)listAppsFragment.getInstance().getSystemService("window");
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.gravity = 17;
        layoutParams.type = 2003;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.alpha = 1.0f;
        layoutParams.packageName = listAppsFragment.getInstance().getPackageName();
        layoutParams.buttonBrightness = 1.0f;
        layoutParams.windowAnimations = 2131230725;
        View view = View.inflate((Context)listAppsFragment.getInstance(), (int)2130968632, (ViewGroup)null);
        Button button = (Button)view.findViewById(2131558605);
        TextView textView = (TextView)view.findViewById(2131558604);
        ((TextView)view.findViewById(2131558478)).setText((CharSequence)string);
        textView.setText((CharSequence)string2);
        button.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                windowManager.removeView(view.getRootView());
            }
        });
        button.setOnKeyListener(new View.OnKeyListener(){

            public boolean onKey(View view, int n, KeyEvent keyEvent) {
                System.out.println("keyCode " + n);
                if (n == 4) {
                    windowManager.removeView(view.getRootView());
                }
                return false;
            }
        });
        windowManager.addView(view, (ViewGroup.LayoutParams)layoutParams);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void startApp(String string) {
        Intent intent = listAppsFragment.getPkgMng().getLaunchIntentForPackage(string);
        if (string == null) {
            System.out.println("Error LP: pkgname is null");
        }
        if (intent == null) {
            System.out.println("Error LP: launch intent is null");
        }
        if (intent == null) {
            Intent intent2 = new Intent("android.intent.action.MAIN", null);
            intent2.addCategory("android.intent.category.LAUNCHER");
            List list = listAppsFragment.getPkgMng().queryIntentActivities(intent2, 0);
            if (list != null) {
                for (ResolveInfo resolveInfo : list) {
                    if (!resolveInfo.activityInfo.packageName.equals((Object)string)) continue;
                    ActivityInfo activityInfo = resolveInfo.activityInfo;
                    ComponentName componentName = new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name);
                    intent = new Intent("android.intent.action.MAIN");
                    intent.addCategory("android.intent.category.LAUNCHER");
                    intent.setComponent(componentName);
                    break;
                }
            }
        }
        if (listAppsFragment.su) {
            if (intent == null) return;
            {
                Utils utils = new Utils("");
                String[] arrstring = new String[]{"am start -n " + string + "/" + intent.getComponent().getClassName()};
                utils.cmdRoot(arrstring);
                return;
            }
        } else {
            if (listAppsFragment.patchAct == null || intent == null) return;
            {
                listAppsFragment.patchAct.startActivity(intent);
                return;
            }
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void startRootJava() {
        String[] arrstring;
        System.out.println("SU Java-Code Running!");
        listAppsFragment.startUnderRoot = true;
        listAppsFragment.toolfilesdir = "";
        new File("/data/lp");
        File file = new File("/data/lp/lp_utils");
        if (!file.exists() || (arrstring = Utils.read_from_file(file).split("%chelpus%")) == null || arrstring.length <= 0) {
            return;
        }
        int n = 0;
        while (n < arrstring.length) {
            switch (n) {
                case 0: {
                    listAppsFragment.toolfilesdir = arrstring[n];
                }
                default: {
                    break;
                }
                case 1: {
                    listAppsFragment.api = Integer.parseInt((String)arrstring[n]);
                }
                case 2: {
                    listAppsFragment.runtime = arrstring[n];
                }
                case 3: {
                    listAppsFragment.selinux = arrstring[n];
                }
            }
            ++n;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void startRootJava(Object object) {
        if (object != null) {
            System.out.println("SU Java-Code Running! " + object.getClass().getEnclosingClass().getName());
        }
        listAppsFragment.startUnderRoot = true;
        listAppsFragment.toolfilesdir = "";
        new File("/data/lp");
        File file = new File("/data/lp/lp_utils");
        if (!file.exists()) {
            if (object == null) return;
            System.out.println("Lucky Patcher not found utils.");
            return;
        }
        String[] arrstring = Utils.read_from_file(file).split("%chelpus%");
        if (arrstring != null && arrstring.length > 0) {
            block6 : for (int i = 0; i < arrstring.length; ++i) {
                switch (i) {
                    case 0: {
                        listAppsFragment.toolfilesdir = arrstring[i];
                    }
                    default: {
                        continue block6;
                    }
                    case 1: {
                        listAppsFragment.api = Integer.parseInt((String)arrstring[i]);
                    }
                    case 2: {
                        listAppsFragment.runtime = arrstring[i];
                    }
                    case 3: {
                        listAppsFragment.selinux = arrstring[i];
                    }
                }
            }
        }
        if (object != null) {
            System.out.println("tools read:" + listAppsFragment.toolfilesdir + "/busybox");
        }
        if (!new File(listAppsFragment.toolfilesdir + "/busybox").exists()) return;
        if (object != null) {
            System.out.println("Lucky Patcher found utils.");
            return;
        }
        if (object == null) return;
        System.out.println("Lucky Patcher not found busybox util.");
    }

    /*
     * Enabled aggressive block sorting
     */
    public static String stringModifyLastChar(String string) {
        byte[] arrby = string.getBytes();
        int n = 0;
        while (n < arrby.length) {
            if (n == -1 + arrby.length) {
                arrby[n] = arrby[n] == 122 ? 65 : (byte)(1 + arrby[n]);
            }
            ++n;
        }
        return new String(arrby);
    }

    public static final void turn_off_patch_on_boot(String string) {
        String string2 = listAppsFragment.getConfig().getString("patch_dalvik_on_boot_patterns", "");
        if (string.contains((CharSequence)"patch1")) {
            listAppsFragment.getConfig().edit().putString("patch_dalvik_on_boot_patterns", string2.replaceAll("patch1", "")).commit();
        }
        String string3 = listAppsFragment.getConfig().getString("patch_dalvik_on_boot_patterns", "");
        if (string.contains((CharSequence)"patch2")) {
            listAppsFragment.getConfig().edit().putString("patch_dalvik_on_boot_patterns", string3.replaceAll("patch2", "")).commit();
        }
        String string4 = listAppsFragment.getConfig().getString("patch_dalvik_on_boot_patterns", "");
        if (string.contains((CharSequence)"patch3")) {
            listAppsFragment.getConfig().edit().putString("patch_dalvik_on_boot_patterns", string4.replaceAll("patch3", "")).commit();
        }
    }

    public static final void turn_off_patch_on_boot_all() {
        listAppsFragment.getConfig().edit().putString("patch_dalvik_on_boot_patterns", "").commit();
    }

    public static final void turn_on_patch_on_boot(String string) {
        String string2 = listAppsFragment.getConfig().getString("patch_dalvik_on_boot_patterns", "");
        if (string.contains((CharSequence)"patch1")) {
            listAppsFragment.getConfig().edit().putString("patch_dalvik_on_boot_patterns", string2.replaceAll("patch1", "") + "patch1").commit();
        }
        String string3 = listAppsFragment.getConfig().getString("patch_dalvik_on_boot_patterns", "");
        if (string.contains((CharSequence)"patch2")) {
            listAppsFragment.getConfig().edit().putString("patch_dalvik_on_boot_patterns", string3.replaceAll("patch2", "") + "patch2").commit();
        }
        String string4 = listAppsFragment.getConfig().getString("patch_dalvik_on_boot_patterns", "");
        if (string.contains((CharSequence)"patch3")) {
            listAppsFragment.getConfig().edit().putString("patch_dalvik_on_boot_patterns", string4.replaceAll("patch3", "") + "patch3").commit();
        }
    }

    public static void verify_and_run(String string, String string2) {
        listAppsFragment.errorOutput = "";
        Utils utils = new Utils("");
        String[] arrstring = new String[]{string + " " + string2};
        utils.cmdRoot(arrstring);
        if (!listAppsFragment.errorOutput.equals((Object)"")) {
            Utils utils2 = new Utils("");
            String[] arrstring2 = new String[]{"busybox " + string + " " + string2};
            utils2.cmdRoot(arrstring2);
        }
        if (!listAppsFragment.errorOutput.equals((Object)"")) {
            Utils utils3 = new Utils("");
            String[] arrstring3 = new String[]{listAppsFragment.toolfilesdir + "/busybox " + string + " " + string2};
            utils3.cmdRoot(arrstring3);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static void verify_bind_and_run(String string, String string2, String string3, String string4) {
        if (string4.trim().startsWith("~chelpus_disabled~")) {
            return;
        }
        String string5 = string3.trim();
        String string6 = string4.trim();
        String string7 = !string5.endsWith("/") ? string5.trim() + "/" : string5;
        String string8 = !string6.endsWith("/") ? string6.trim() + "/" : string6;
        new File(string6).mkdirs();
        new File(string5).mkdirs();
        if (!new File(string6).exists()) {
            Utils.verify_and_run("mkdir", "-p '" + string6 + "'");
        }
        if (!new File(string5).exists()) {
            Utils.verify_and_run("mkdir", "-p '" + string5 + "'");
        }
        try {
            new File(string7 + "test.txt").createNewFile();
        }
        catch (IOException var10_14) {
            var10_14.printStackTrace();
        }
        Utils.run_all("echo '' >'" + string7 + "test.txt'");
        if (!Utils.exists(string8 + "test.txt")) {
            Utils.run_all("umount '" + string6 + "'");
            System.out.println("data: " + string7 + "test.txt");
            System.out.println("target: " + string8 + "test.txt");
            try {
                new File(string7 + "test.txt").createNewFile();
            }
            catch (IOException var12_15) {
                var12_15.printStackTrace();
            }
            Utils.run_all("echo '' >'" + string7 + "test.txt'");
            if (!Utils.exists(string8 + "test.txt")) {
                Utils utils = new Utils("");
                String[] arrstring = new String[]{"busybox " + string + " " + string2};
                utils.cmdRoot(arrstring);
                try {
                    new File(string7 + "test.txt").createNewFile();
                }
                catch (IOException var16_16) {
                    var16_16.printStackTrace();
                }
                Utils.run_all("echo '' >'" + string7 + "test.txt'");
                if (!Utils.exists(string8 + "test.txt")) {
                    Utils utils2 = new Utils("");
                    String[] arrstring2 = new String[]{listAppsFragment.toolfilesdir + "/busybox " + string + " " + string2};
                    utils2.cmdRoot(arrstring2);
                    Utils utils3 = new Utils("");
                    String[] arrstring3 = new String[]{"busybox " + string + " " + string2};
                    utils3.cmdRoot(arrstring3);
                    try {
                        new File(string7 + "test.txt").createNewFile();
                    }
                    catch (IOException var23_17) {
                        var23_17.printStackTrace();
                    }
                    Utils.run_all("echo '' >'" + string7 + "test.txt'");
                    if (!Utils.exists(string8 + "test.txt")) {
                        System.out.println("LuckyPatcher(Binder error): bind not created!");
                    }
                }
            }
        } else {
            System.out.println("LuckyPatcher(Binder): " + string6 + " exists!");
        }
        if (!Utils.exists(string7 + "test.txt")) return;
        if (Utils.exists(string8 + "test.txt")) {
            System.out.println("LuckyPatcher(Binder): " + string6 + " binded!");
        } else {
            System.out.println("LuckyPatcher(Binder error): " + string6 + " not binded!");
        }
        new File(string7 + "test.txt").delete();
        if (!Utils.exists(string7 + "test.txt")) return;
        Utils.run_all("rm '" + string7 + "test.txt'");
    }

    /*
     * Exception decompiling
     */
    public static void zip(String var0_1, String var1, ArrayList<File> var2_3, String var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static String zipART(String var0_1, String var1, ArrayList<File> var2_3, String var3_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [6[CATCHBLOCK], 5[CATCHBLOCK]], but top level block is 9[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public /* varargs */ String cmdRoot(String ... var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 9[UNCONDITIONALDOLOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public void deleteFolder(File file) throws IOException {
        if (!file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            File[] arrfile = file.listFiles();
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                this.deleteFolder(arrfile[i]);
            }
        }
        new File(file.toString()).delete();
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public String findFile(File file, String string) throws IOException {
        if (!file.exists()) {
            return "";
        }
        if (file.isDirectory()) {
            File[] arrfile = file.listFiles();
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                String string2 = this.findFile(arrfile[i], string);
                if (!string2.equals((Object)"")) return string2;
            }
        }
        if (!file.getName().equals((Object)string)) return "";
        return file.getAbsolutePath();
    }

    public String findFileContainText(File file, String string) throws IOException {
        if (file.isDirectory()) {
            File[] arrfile = file.listFiles();
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                String string2 = this.findFileContainText(arrfile[i], string);
                if (string2.equals((Object)"")) continue;
                return string2;
            }
        }
        if (file.getName().contains((CharSequence)string)) {
            return file.getAbsolutePath();
        }
        return "";
    }

    public String findFileEndText(File file, String string, ArrayList<File> arrayList) throws IOException {
        if (!file.exists()) {
            return "";
        }
        if (file.isDirectory()) {
            File[] arrfile = file.listFiles();
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                String string2 = this.findFileEndText(arrfile[i], string, arrayList);
                if (string2.equals((Object)"")) continue;
                Utils.addFileToList(new File(string2), arrayList);
            }
        }
        if (file.getName().endsWith(string)) {
            Utils.addFileToList(file, arrayList);
            return file.getAbsolutePath();
        }
        return "";
    }

    public void fixOwners(File file, String string) throws IOException {
        String[] arrstring = new String[]{"chown", string, file.getAbsolutePath()};
        Utils.run_all_no_root(arrstring);
        if (file.isDirectory()) {
            for (File file2 : file.listFiles()) {
                String[] arrstring2 = new String[]{"chown", string, file.getAbsolutePath()};
                Utils.run_all_no_root(arrstring2);
                this.fixOwners(file2, string);
            }
        }
    }

    public void fixPermissions(File file, String string) throws IOException {
        String[] arrstring = new String[]{"chmod", string, file.getAbsolutePath()};
        Utils.run_all_no_root(arrstring);
        if (file.isDirectory()) {
            for (File file2 : file.listFiles()) {
                String[] arrstring2 = new String[]{"chmod", string, file.getAbsolutePath()};
                Utils.run_all_no_root(arrstring2);
                this.fixPermissions(file2, string);
            }
        }
    }

    /*
     * Exception decompiling
     */
    public String getInput(boolean var1, Worker var2_2) throws Exception {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 5[WHILELOOP]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public OatFuncDump getOffsetOatdump(File var1, ArrayList<String> var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK]], but top level block is 6[CATCHBLOCK]
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void setAllReadable(File file) {
        File[] arrfile;
        int n2;
        int n;
        try {
            file.setReadable(true);
            if (!file.isDirectory()) return;
            arrfile = file.listFiles();
            n = arrfile.length;
            n2 = 0;
        }
        catch (Exception var3_6) {
            var3_6.printStackTrace();
        }
        return;
        catch (NoSuchMethodError noSuchMethodError) {
            noSuchMethodError.printStackTrace();
            return;
        }
        while (n2 < n) {
            File file2 = arrfile[n2];
            file.setReadable(true);
            this.setAllReadable(file2);
            ++n2;
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public void setAllWritable(File file) {
        File[] arrfile;
        int n2;
        int n;
        try {
            file.setWritable(true);
            if (!file.isDirectory()) return;
            arrfile = file.listFiles();
            n = arrfile.length;
            n2 = 0;
        }
        catch (Exception var3_6) {
            var3_6.printStackTrace();
        }
        return;
        catch (NoSuchMethodError noSuchMethodError) {
            noSuchMethodError.printStackTrace();
            return;
        }
        while (n2 < n) {
            File file2 = arrfile[n2];
            file.setWritable(true);
            this.setAllWritable(file2);
            ++n2;
        }
    }

    public float sizeFolder(File file, boolean bl) throws IOException {
        if (bl) {
            this.folder_size = 0.0f;
        }
        if (file.isDirectory()) {
            File[] arrfile = file.listFiles();
            int n = arrfile.length;
            for (int i = 0; i < n; ++i) {
                this.sizeFolder(arrfile[i], false);
            }
        }
        this.folder_size += (float)new File(file.toString()).length();
        return this.folder_size / 1048576.0f;
    }

    /*
     * Exception decompiling
     */
    public void waitLP(long var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.util.ConcurrentModificationException
        // java.util.LinkedList$ReverseLinkIterator.next(LinkedList.java:217)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.extractLabelledBlocks(Block.java:212)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:485)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.StructuredWhile.transformStructuredChildren(StructuredWhile.java:50)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.structured.statement.Block.transformStructuredChildren(Block.java:378)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement$LabelledBlockExtractor.transform(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.transform(Op04StructuredStatement.java:639)
        // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.insertLabelledBlocks(Op04StructuredStatement.java:649)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:816)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
        // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
        // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
        // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
        // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
        // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
        // org.benf.cfr.reader.Main.doJar(Main.java:128)
        // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
        // java.lang.Thread.run(Thread.java:818)
        throw new IllegalStateException("Decompilation failed");
    }

    public class OatFunc {
        public int codeOffset;
        public int codeSize;
        public String funcName;

        public OatFunc(String string, int n, int n2) {
            this.funcName = null;
            this.codeOffset = 0;
            this.codeSize = 0;
            this.funcName = string;
            this.codeOffset = n;
            this.codeSize = n2;
        }
    }

    public class OatFuncDump {
        public ArrayList<OatFunc> funcArray;
        public String instruction;

        public OatFuncDump() {
            this.instruction = null;
            this.funcArray = new ArrayList();
        }
    }

    class RootTimerTask
    extends TimerTask {
        Worker work;

        public RootTimerTask(Worker worker) {
            this.work = null;
            this.work = worker;
        }

        /*
         * Exception decompiling
         */
        public void run() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [3[TRYBLOCK], 0[TRYBLOCK]], but top level block is 9[CATCHBLOCK]
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:128)
            // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
            // java.lang.Thread.run(Thread.java:818)
            throw new IllegalStateException("Decompilation failed");
        }
    }

    private class Worker
    extends Thread {
        private String[] commands;
        private Integer exitCode;
        public DataInputStream input;
        public long lastTimeGetStream;
        private String result;
        final /* synthetic */ Utils this$0;

        private Worker(Utils utils) {
            this.this$0 = utils;
            this.result = "";
            this.commands = null;
            this.exitCode = null;
            this.input = null;
            this.lastTimeGetStream = 0;
        }

        /* synthetic */ Worker(Utils utils,  var2_2) {
            super(utils);
        }

        static /* synthetic */ String[] access$100(Worker worker) {
            return worker.commands;
        }

        static /* synthetic */ String[] access$102(Worker worker, String[] arrstring) {
            worker.commands = arrstring;
            return arrstring;
        }

        static /* synthetic */ Integer access$200(Worker worker) {
            return worker.exitCode;
        }

        static /* synthetic */ String access$300(Worker worker) {
            return worker.result;
        }

        /*
         * Exception decompiling
         */
        public void run() {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [2[TRYBLOCK]], but top level block is 16[UNCONDITIONALDOLOOP]
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:394)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:446)
            // org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:2859)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:805)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:220)
            // org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:165)
            // org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:91)
            // org.benf.cfr.reader.entities.Method.analyse(Method.java:354)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:751)
            // org.benf.cfr.reader.entities.ClassFile.analyseInnerClassesPass1(ClassFile.java:664)
            // org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:747)
            // org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:683)
            // org.benf.cfr.reader.Main.doJar(Main.java:128)
            // com.njlabs.showjava.processor.JavaExtractor$1.run(JavaExtractor.java:100)
            // java.lang.Thread.run(Thread.java:818)
            throw new IllegalStateException("Decompilation failed");
        }
    }

}

