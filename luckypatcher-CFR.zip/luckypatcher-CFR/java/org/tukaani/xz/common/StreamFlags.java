/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.tukaani.xz.common;

public class StreamFlags {
    public long backwardSize = -1;
    public int checkType = -1;
}

