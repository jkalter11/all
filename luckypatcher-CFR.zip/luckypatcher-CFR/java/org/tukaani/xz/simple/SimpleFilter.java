/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package org.tukaani.xz.simple;

public interface SimpleFilter {
    public int code(byte[] var1, int var2, int var3);
}

