/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 */
package org.tukaani.xz;

class IndexIndicatorException
extends Exception {
    private static final long serialVersionUID = 1;

    IndexIndicatorException() {
    }
}

