/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package pxb.android;

public interface ResConst {
    public static final int RES_STRING_POOL_TYPE = 1;
    public static final int RES_TABLE_PACKAGE_TYPE = 512;
    public static final int RES_TABLE_TYPE = 2;
    public static final int RES_TABLE_TYPE_SPEC_TYPE = 514;
    public static final int RES_TABLE_TYPE_TYPE = 513;
    public static final int RES_XML_CDATA_TYPE = 260;
    public static final int RES_XML_END_ELEMENT_TYPE = 259;
    public static final int RES_XML_END_NAMESPACE_TYPE = 257;
    public static final int RES_XML_RESOURCE_MAP_TYPE = 384;
    public static final int RES_XML_START_ELEMENT_TYPE = 258;
    public static final int RES_XML_START_NAMESPACE_TYPE = 256;
    public static final int RES_XML_TYPE = 3;
}

