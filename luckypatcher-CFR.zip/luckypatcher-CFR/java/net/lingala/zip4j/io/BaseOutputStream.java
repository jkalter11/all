/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.io.OutputStream
 */
package net.lingala.zip4j.io;

import java.io.IOException;
import java.io.OutputStream;

public abstract class BaseOutputStream
extends OutputStream {
    public void write(int n) throws IOException {
    }
}

