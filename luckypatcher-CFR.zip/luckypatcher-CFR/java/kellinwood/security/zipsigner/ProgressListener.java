/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package kellinwood.security.zipsigner;

import kellinwood.security.zipsigner.ProgressEvent;

public interface ProgressListener {
    public void onProgress(ProgressEvent var1);
}

