/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 */
package kellinwood.security.zipsigner.optional;

public class KeyNameConflictException
extends Exception {
}

