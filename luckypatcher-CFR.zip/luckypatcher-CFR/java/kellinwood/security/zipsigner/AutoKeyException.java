/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.Throwable
 */
package kellinwood.security.zipsigner;

public class AutoKeyException
extends RuntimeException {
    private static final long serialVersionUID = 1;

    public AutoKeyException(String string) {
        super(string);
    }

    public AutoKeyException(String string, Throwable throwable) {
        super(string, throwable);
    }
}

