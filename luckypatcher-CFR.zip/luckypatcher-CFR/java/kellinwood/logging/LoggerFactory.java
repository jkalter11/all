/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package kellinwood.logging;

import kellinwood.logging.LoggerInterface;

public interface LoggerFactory {
    public LoggerInterface getLogger(String var1);
}

