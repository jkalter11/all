package com.doomonafireball.macrodroid;

public class AFood {
    private String foodName;
    private String foodServingSize;
    private float foodGramsProtein;
    private float foodGramsCarbs;
    private float foodGramsFat;
    private float foodKCal;
    
    public String getFoodName() {
        return foodName;
    }
    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }
    public String getFoodServingSize() {
        return foodServingSize;
    }
    public void setFoodServingSize(String foodServingSize) {
        this.foodServingSize = foodServingSize;
    }
    public float getFoodGramsProtein() {
        return foodGramsProtein;
    }
    public void setFoodGramsProtein(float foodGramsProtein) {
        this.foodGramsProtein = foodGramsProtein;
    }
    public float getFoodGramsCarbs() {
        return foodGramsCarbs;
    }
    public void setFoodGramsCarbs(float foodGramsCarbs) {
        this.foodGramsCarbs = foodGramsCarbs;
    }
    public float getFoodGramsFat() {
        return foodGramsFat;
    }
    public void setFoodGramsFat(float foodGramsFat) {
        this.foodGramsFat = foodGramsFat;
    }
    public float getFoodKCal() {
        return foodKCal;
    }
    public void setFoodKCal(float foodKCal) {
        this.foodKCal = foodKCal;
    }
}
