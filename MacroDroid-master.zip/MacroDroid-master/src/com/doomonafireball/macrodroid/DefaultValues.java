package com.doomonafireball.macrodroid;

public class DefaultValues {
    // Macro Conversions
    public static final float MACRO_CONVERSION_PROTEIN = 4.0f;
    public static final float MACRO_CONVERSION_CARBS = 4.0f;
    public static final float MACRO_CONVERSION_FAT = 9.0f;

}
