# FaceUnclok
Android Simple Face Unlock Screen  

miniSDK = 22

# close screen  
OnStart -> OnResume -> OnPause

#open screen
OnStart -> OnResume
